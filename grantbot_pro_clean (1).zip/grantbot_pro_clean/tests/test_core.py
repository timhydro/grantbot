from grantbot.matching.matcher import match_grant
from grantbot.grants.writer import write_grant_answer

def test_hard_reject_academic():
    g={"id":"1","title":"Postdoctoral Research Fellowships in Biology","description":"employment workforce research fellowship","applicant_types":[{"description":"Individuals"}]}
    r=match_grant(g,("employment","workforce","reentry"))
    assert r["priority"]=="REJECT" and r["match_score"]==0

def test_good_program_scores():
    g={"id":"2","title":"Workforce Reentry Employment Program","description":"reentry employment job training workforce development for formerly incarcerated adults and homeless people","applicant_types":[{"description":"Nonprofits having a 501(c)(3) status"}]}
    r=match_grant(g,("reentry","homelessness","employment","workforce"))
    assert r["match_score"]>=70 and r["priority"] in {"MEDIUM","HIGH"}

def test_writer_uses_only_verified_facts():
    facts=[{"fact_key":"EMP_PLAN","category":"employment","value":"The organization plans to provide workforce development and employment opportunities.","status":"APPROVED"},{"fact_key":"FAKE","category":"employment","value":"100 people were placed in jobs.","status":"DRAFT"}]
    r=write_grant_answer("How will you provide employment and job training?",facts)
    assert "100 people" not in r["narrative"]
