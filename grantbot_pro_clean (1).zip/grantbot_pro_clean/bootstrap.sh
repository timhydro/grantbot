#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv venv
./venv/bin/python -m pip install --upgrade pip
./venv/bin/pip install -r requirements.txt
cp -n .env.example .env || true
./venv/bin/python -m grantbot.cli init
./venv/bin/pytest -q
printf '\nGRANTBOT PRO CLEAN BUILD: READY\n'
