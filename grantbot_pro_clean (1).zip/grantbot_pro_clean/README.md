# GrantBot Pro — Clean Production Rebuild

This rebuild intentionally removes mock AI providers, fabricated fallback data, placeholder narrative injection, and unsupported claim generation.

## Install
```bash
sudo apt update && sudo apt install -y python3 python3-venv python3-pip unzip
./bootstrap.sh
```

## Real Grants.gov search
```bash
./venv/bin/python -m grantbot.cli search "reentry" --rows 5 --details
```

## Store an approved fact
```bash
./venv/bin/python -m grantbot.cli set-fact ORG_MISSION mission "..." --status APPROVED --provenance FOUNDER_FACT
```

## Grant writing
Deterministic mode only assembles approved/verified facts. Optional Ollama mode is enabled only when `GRANTBOT_OLLAMA_MODEL` is explicitly configured.
```bash
./venv/bin/python -m grantbot.cli write "How will your program provide employment and job training?"
```
