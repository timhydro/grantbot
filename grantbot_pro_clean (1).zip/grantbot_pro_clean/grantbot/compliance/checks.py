from __future__ import annotations
from typing import Iterable

def check_limits(text:str, word_limit:int|None=None, character_limit:int|None=None)->dict:
    words=len((text or "").split()); chars=len(text or ""); issues=[]
    if word_limit is not None and words>word_limit: issues.append(f"Word limit exceeded by {words-word_limit} words.")
    if character_limit is not None and chars>character_limit: issues.append(f"Character limit exceeded by {chars-character_limit} characters.")
    return {"passed":not issues,"word_count":words,"character_count":chars,"issues":issues}

def check_required_concepts(text:str, concepts:Iterable[str])->dict:
    missing=[c for c in concepts if c.lower() not in (text or "").lower()]
    return {"passed":not missing,"missing_concepts":missing}
