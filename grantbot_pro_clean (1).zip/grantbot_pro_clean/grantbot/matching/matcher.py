from __future__ import annotations
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Tuple

CATEGORY_WEIGHTS={"reentry":20,"homelessness":20,"housing":20,"employment":15,"workforce":15,"supportive_services":10}
KEYWORDS={
 "reentry":("reentry","formerly incarcerated","incarcerated","justice involved","justice-involved","returning citizen","criminal justice"),
 "homelessness":("homeless","homelessness","unsheltered"),
 "housing":("housing","supportive housing","transitional housing","affordable housing","tiny home"),
 "employment":("employment","job placement","jobs","economic opportunity"),
 "workforce":("workforce","job training","employment training","career training","workforce development"),
 "supportive_services":("supportive services","case management","mentoring","life skills","resource navigation","community support"),
}
HARD_RULES={
 "academic/research-only applicant":("postdoctoral","postdoctoral research","doctoral fellowship","research fellowship"),
 "tribal institution applicant":("tribal college","tribal university"),
 "law-enforcement applicant":("law enforcement agency","police department","sheriff's office","community policing development"),
 "foreign/international program":("annual program statement (aps)","embassy small grants","foreign assistance","international development","syria annual program statement"),
}
NONPROFIT_TERMS=("nonprofits","nonprofit organizations","non-profit organizations","501(c)(3)","public and state controlled institutions","private institutions of higher education")

def _flatten(v:Any)->str:
    if isinstance(v,dict): return " ".join(_flatten(x) for x in v.values())
    if isinstance(v,(list,tuple,set)): return " ".join(_flatten(x) for x in v)
    return str(v or "")

def grant_text(g:Dict[str,Any])->str:
    return " ".join(_flatten(g.get(k)) for k in ("title","agency","description","eligibility","applicant_types","funding_categories","assistance_listings")).lower()

def categories(text:str)->List[str]:
    return [c for c,terms in KEYWORDS.items() if any(t in text for t in terms)]

def deadline_info(raw:Any)->Dict[str,Any]:
    if not raw: return {"deadline_known":False,"days_remaining":None,"deadline_priority":"UNKNOWN"}
    s=str(raw).strip()
    fmts=("%m/%d/%Y","%Y-%m-%d","%m-%d-%Y","%Y-%m-%d-%H-%M-%S","%b %d, %Y %I:%M:%S %p %Z")
    dt=None
    for f in fmts:
        try: dt=datetime.strptime(s[:len(s)],f); break
        except ValueError: pass
    if dt is None:
        import re
        m=re.search(r"(\d{1,2}/\d{1,2}/\d{4}|\d{4}-\d{2}-\d{2})",s)
        if m:
            for f in ("%m/%d/%Y","%Y-%m-%d"):
                try: dt=datetime.strptime(m.group(1),f); break
                except ValueError: pass
    if dt is None: return {"deadline_known":False,"days_remaining":None,"deadline_priority":"UNKNOWN"}
    days=(dt.date()-datetime.now(timezone.utc).date()).days
    p="CLOSED" if days<0 else "URGENT" if days<=7 else "HIGH" if days<=30 else "MEDIUM" if days<=90 else "LOW"
    return {"deadline_known":True,"days_remaining":days,"deadline_priority":p}

def match_grant(grant:Dict[str,Any], organization_categories:Iterable[str], organization_is_nonprofit:bool=True)->Dict[str,Any]:
    text=grant_text(grant); matched=categories(text); org=set(organization_categories)
    reasons=[]; warnings=[]; hard=[]
    for reason,terms in HARD_RULES.items():
        if any(t in text for t in terms): hard.append(reason)
    applicant_text=_flatten(grant.get("applicant_types") or grant.get("eligibility")).lower()
    eligibility_known=bool(applicant_text.strip())
    nonprofit_eligible=any(t in applicant_text for t in NONPROFIT_TERMS)
    if organization_is_nonprofit and eligibility_known and not nonprofit_eligible:
        # Do not hard reject generic categories automatically; only state that nonprofit eligibility is not evidenced.
        warnings.append("Detailed applicant types do not explicitly show nonprofit eligibility; verify the official NOFO.")
    score=sum(CATEGORY_WEIGHTS[c] for c in matched if c in org)
    for c in matched:
        if c in org: reasons.append(f"Program fit: {c}.")
    if nonprofit_eligible:
        score=min(100,score+10); reasons.append("Applicant-type data includes nonprofit eligibility.")
    if hard:
        score=0; priority="REJECT"; reasons.append("Hard eligibility conflict: "+", ".join(dict.fromkeys(hard))+".")
    elif score>=75: priority="HIGH"
    elif score>=50: priority="MEDIUM"
    elif score>=25: priority="LOW"
    else: priority="REJECT"
    deadline=deadline_info(grant.get("close_date"))
    if deadline["deadline_priority"]=="CLOSED": priority="CLOSED"
    if not grant.get("agency"): warnings.append("Funding agency not identified in retrieved data.")
    if not deadline["deadline_known"]: warnings.append("Deadline was not reliably parsed; verify official NOFO.")
    if not eligibility_known: warnings.append("Applicant eligibility was not available in retrieved details; verify official NOFO.")
    return {**grant,"match_score":max(0,min(100,score)),"priority":priority,"matched_categories":matched,"reasons":reasons,"eligibility_warnings":warnings,"hard_reject_reasons":hard,"nonprofit_eligibility_evidenced":nonprofit_eligible,**deadline}
