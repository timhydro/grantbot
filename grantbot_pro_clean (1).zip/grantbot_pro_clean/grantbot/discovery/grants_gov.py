from __future__ import annotations
import json
from typing import Any, Dict, Iterable, List
import requests
from grantbot.core.config import HTTP_TIMEOUT
from grantbot.data.db import connect, init_db, now, audit

SEARCH_URL="https://api.grants.gov/v1/api/search2"
FETCH_URL="https://api.grants.gov/v1/api/fetchOpportunity"

class GrantsGovError(RuntimeError): pass

def _post(url:str,payload:Dict[str,Any])->Dict[str,Any]:
    try:
        r=requests.post(url,json=payload,timeout=HTTP_TIMEOUT,headers={"Accept":"application/json","User-Agent":"GrantBotPro/1.0"})
        r.raise_for_status()
        data=r.json()
    except requests.RequestException as exc:
        raise GrantsGovError(f"Grants.gov request failed: {exc}") from exc
    except ValueError as exc:
        raise GrantsGovError("Grants.gov returned invalid JSON") from exc
    if int(data.get("errorcode",0) or 0)!=0:
        raise GrantsGovError(str(data.get("msg") or "Grants.gov API error"))
    return data

def search_grants(keyword:str, rows:int=25, statuses:str="posted|forecasted", start_record:int=0)->List[Dict[str,Any]]:
    if not keyword.strip(): raise ValueError("keyword is required")
    rows=max(1,min(int(rows),1000))
    payload={"keyword":keyword.strip(),"rows":rows,"oppStatuses":statuses,"startRecordNum":max(0,int(start_record))}
    result=_post(SEARCH_URL,payload); hits=(result.get("data") or {}).get("oppHits") or []
    return [{"source":"Grants.gov","id":str(x.get("id")),"opportunity_number":x.get("number"),"title":x.get("title") or "","agency_code":x.get("agencyCode"),"agency":x.get("agencyName"),"open_date":x.get("openDate"),"close_date":x.get("closeDate"),"status":x.get("oppStatus"),"document_type":x.get("docType"),"assistance_listings":x.get("alnist") or [],"search_keyword":keyword.strip()} for x in hits if x.get("id") and x.get("title")]

def fetch_opportunity(opportunity_id:str|int)->Dict[str,Any]:
    if str(opportunity_id).strip()=="": raise ValueError("opportunity_id is required")
    data=(_post(FETCH_URL,{"opportunityId":int(opportunity_id)}).get("data") or {})
    syn=data.get("synopsis") or {}; agency=data.get("agencyDetails") or {}; top=data.get("topAgencyDetails") or {}
    applicant=syn.get("applicantTypes") or []
    inst=syn.get("fundingInstruments") or []
    cats=syn.get("fundingActivityCategories") or []
    alns=data.get("alns") or []
    def num(v):
        try: return float(str(v).replace(",", "")) if v not in (None,"") else None
        except (TypeError,ValueError): return None
    return {
        "source":"Grants.gov","id":str(data.get("id") or opportunity_id),"opportunity_number":data.get("opportunityNumber"),"title":data.get("opportunityTitle") or "",
        "agency":syn.get("agencyName") or agency.get("agencyName") or top.get("agencyName"),"agency_code":syn.get("agencyCode") or data.get("owningAgencyCode") or agency.get("agencyCode"),
        "description":syn.get("synopsisDesc") or "","eligibility":applicant,"applicant_types":applicant,
        "open_date":syn.get("postingDateStr") or syn.get("postingDate"),"close_date":syn.get("responseDateStr") or syn.get("responseDateDesc"),"status":data.get("docType"),
        "award_floor":num(syn.get("awardFloor")),"award_ceiling":num(syn.get("awardCeiling")),"cost_sharing":syn.get("costSharing"),
        "funding_instruments":inst,"funding_categories":cats,"assistance_listings":alns,"agency_contact_name":syn.get("agencyContactName"),"agency_contact_email":syn.get("agencyContactEmail"),"agency_contact_phone":syn.get("agencyContactPhone"),
        "details_loaded":True,"raw":data,
    }

def enrich_search_result(grant:Dict[str,Any])->Dict[str,Any]:
    detail=fetch_opportunity(grant["id"])
    merged=dict(grant)
    for k,v in detail.items():
        if v not in (None,"",[]): merged[k]=v
    return merged

def save_opportunity(grant:Dict[str,Any])->None:
    init_db(); raw=grant.get("raw") or grant
    with connect() as con:
        con.execute("""INSERT INTO opportunities(id,opportunity_number,title,agency,agency_code,description,eligibility_json,applicant_types_json,open_date,close_date,status,award_floor,award_ceiling,funding_instruments_json,funding_categories_json,assistance_listings_json,source,details_loaded,raw_json,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET opportunity_number=excluded.opportunity_number,title=excluded.title,agency=excluded.agency,agency_code=excluded.agency_code,description=excluded.description,eligibility_json=excluded.eligibility_json,applicant_types_json=excluded.applicant_types_json,open_date=excluded.open_date,close_date=excluded.close_date,status=excluded.status,award_floor=excluded.award_floor,award_ceiling=excluded.award_ceiling,funding_instruments_json=excluded.funding_instruments_json,funding_categories_json=excluded.funding_categories_json,assistance_listings_json=excluded.assistance_listings_json,source=excluded.source,details_loaded=excluded.details_loaded,raw_json=excluded.raw_json,updated_at=excluded.updated_at""",
        (str(grant["id"]),grant.get("opportunity_number"),grant.get("title") or "",grant.get("agency"),grant.get("agency_code"),grant.get("description") or "",json.dumps(grant.get("eligibility") or []),json.dumps(grant.get("applicant_types") or []),grant.get("open_date"),grant.get("close_date"),grant.get("status"),grant.get("award_floor"),grant.get("award_ceiling"),json.dumps(grant.get("funding_instruments") or []),json.dumps(grant.get("funding_categories") or []),json.dumps(grant.get("assistance_listings") or []),grant.get("source") or "Grants.gov",int(bool(grant.get("details_loaded"))),json.dumps(raw,default=str),now()))
    audit("opportunity_saved",f"Saved {grant.get('title')}","opportunity",str(grant["id"]))

DEFAULT_KEYWORDS=("reentry","formerly incarcerated","workforce development","employment training","homelessness","supportive housing","transitional housing","community development","job training","economic opportunity")

def discover(keywords:Iterable[str]=DEFAULT_KEYWORDS, rows_per_keyword:int=10, enrich:bool=True)->List[Dict[str,Any]]:
    seen=set(); out=[]
    for kw in keywords:
        for g in search_grants(kw,rows=rows_per_keyword):
            key=g.get("opportunity_number") or g["id"]
            if key in seen: continue
            seen.add(key)
            try: item=enrich_search_result(g) if enrich else g
            except GrantsGovError as exc:
                item=dict(g); item["details_loaded"]=False; item["detail_error"]=str(exc)
            save_opportunity(item); out.append(item)
    return out
