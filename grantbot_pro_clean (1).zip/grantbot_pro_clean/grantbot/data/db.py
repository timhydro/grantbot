from __future__ import annotations
import json, sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional
from grantbot.core.config import DB_PATH

SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS sources(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 source_key TEXT NOT NULL UNIQUE,
 title TEXT NOT NULL,
 source_type TEXT NOT NULL,
 location TEXT,
 citation TEXT,
 verified INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS facts(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 fact_key TEXT NOT NULL,
 category TEXT NOT NULL,
 value_json TEXT NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('APPROVED','VERIFIED','DRAFT','MISSING')),
 provenance TEXT NOT NULL CHECK(provenance IN ('FOUNDER_FACT','DOCUMENT_FACT','OFFICIAL_SOURCE','CALCULATION','INFERENCE','DRAFT_LANGUAGE')),
 reusable INTEGER NOT NULL DEFAULT 1,
 sensitive INTEGER NOT NULL DEFAULT 0,
 source_key TEXT,
 valid_from TEXT NOT NULL,
 valid_to TEXT,
 created_at TEXT NOT NULL,
 FOREIGN KEY(source_key) REFERENCES sources(source_key)
);
CREATE INDEX IF NOT EXISTS idx_facts_active ON facts(fact_key, valid_to);
CREATE TABLE IF NOT EXISTS opportunities(
 id TEXT PRIMARY KEY,
 opportunity_number TEXT,
 title TEXT NOT NULL,
 agency TEXT,
 agency_code TEXT,
 description TEXT NOT NULL DEFAULT '',
 eligibility_json TEXT NOT NULL DEFAULT '[]',
 applicant_types_json TEXT NOT NULL DEFAULT '[]',
 open_date TEXT,
 close_date TEXT,
 status TEXT,
 award_floor REAL,
 award_ceiling REAL,
 funding_instruments_json TEXT NOT NULL DEFAULT '[]',
 funding_categories_json TEXT NOT NULL DEFAULT '[]',
 assistance_listings_json TEXT NOT NULL DEFAULT '[]',
 source TEXT NOT NULL,
 details_loaded INTEGER NOT NULL DEFAULT 0,
 raw_json TEXT NOT NULL,
 updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 event_type TEXT NOT NULL,
 entity_type TEXT,
 entity_id TEXT,
 message TEXT NOT NULL,
 data_json TEXT NOT NULL DEFAULT '{}',
 created_at TEXT NOT NULL
);
"""

def now() -> str:
    return datetime.now(timezone.utc).isoformat()

@contextmanager
def connect(path: Path = DB_PATH):
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    try:
        yield con
        con.commit()
    finally:
        con.close()

def init_db(path: Path = DB_PATH) -> None:
    with connect(path) as con:
        con.executescript(SCHEMA)

def audit(event_type: str, message: str, entity_type: str | None = None, entity_id: str | None = None, data: Dict[str, Any] | None = None) -> None:
    with connect() as con:
        con.execute("INSERT INTO audit(event_type,entity_type,entity_id,message,data_json,created_at) VALUES(?,?,?,?,?,?)",
                    (event_type, entity_type, entity_id, message, json.dumps(data or {}, default=str), now()))
