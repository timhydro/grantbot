from __future__ import annotations
import argparse, json
from grantbot.data.db import init_db
from grantbot.knowledge.store import KnowledgeStore
from grantbot.discovery.grants_gov import discover, search_grants, enrich_search_result
from grantbot.matching.matcher import match_grant
from grantbot.grants.writer import write_grant_answer

ORG_CATEGORIES=("reentry","homelessness","housing","employment","workforce","supportive_services")

def main():
    p=argparse.ArgumentParser(prog="grantbot"); sub=p.add_subparsers(dest="cmd",required=True)
    sub.add_parser("init")
    a=sub.add_parser("set-fact"); a.add_argument("fact_key"); a.add_argument("category"); a.add_argument("value"); a.add_argument("--status",choices=("APPROVED","VERIFIED","DRAFT","MISSING"),default="APPROVED"); a.add_argument("--provenance",choices=("FOUNDER_FACT","DOCUMENT_FACT","OFFICIAL_SOURCE","CALCULATION","INFERENCE","DRAFT_LANGUAGE"),default="FOUNDER_FACT")
    sub.add_parser("facts")
    s=sub.add_parser("search"); s.add_argument("keyword"); s.add_argument("--rows",type=int,default=10); s.add_argument("--details",action="store_true")
    d=sub.add_parser("discover"); d.add_argument("--rows",type=int,default=5)
    m=sub.add_parser("match"); m.add_argument("opportunity_id")
    w=sub.add_parser("write"); w.add_argument("question"); w.add_argument("--ollama",action="store_true")
    args=p.parse_args(); kb=KnowledgeStore()
    if args.cmd=="init": init_db(); print("GRANTBOT PRO DATABASE: READY")
    elif args.cmd=="set-fact": print(kb.set_fact(args.fact_key,args.category,args.value,args.status,args.provenance))
    elif args.cmd=="facts": print(json.dumps(kb.list_facts(allowed_statuses=("APPROVED","VERIFIED","DRAFT","MISSING"),reusable_only=False),indent=2,default=str))
    elif args.cmd=="search":
        items=search_grants(args.keyword,args.rows)
        if args.details: items=[enrich_search_result(x) for x in items]
        print(json.dumps(items,indent=2,default=str))
    elif args.cmd=="discover": print(json.dumps(discover(rows_per_keyword=args.rows),indent=2,default=str))
    elif args.cmd=="match":
        g=enrich_search_result({"id":args.opportunity_id,"title":"","source":"Grants.gov"}); print(json.dumps(match_grant(g,ORG_CATEGORIES),indent=2,default=str))
    elif args.cmd=="write": print(json.dumps(write_grant_answer(args.question,kb.list_facts(),args.ollama),indent=2,default=str))

if __name__=="__main__": main()
