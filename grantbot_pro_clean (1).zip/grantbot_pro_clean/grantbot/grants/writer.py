from __future__ import annotations
import json, re
from typing import Any, Dict, Iterable, List
import requests
from grantbot.core.config import HTTP_TIMEOUT, OLLAMA_MODEL, OLLAMA_URL
from grantbot.grants.claim_checker import check_claims

DOMAIN_TERMS={
 "employment":("employment","workforce","job","training","wage","position","certification","advancement","transportation","employer"),
 "housing":("housing","home","tiny home","shelter","rent","resident","transitional"),
 "reentry":("reentry","incarcerated","jail","prison","returning citizen","justice-involved","probation"),
 "homelessness":("homeless","unsheltered","housing instability"),
 "capacity":("leadership","board","staff","experience","capacity","partner"),
 "financial":("budget","revenue","expense","funding","financial","cost"),
 "outcomes":("outcome","measure","evaluation","retention","served","impact","recidivism"),
}

def infer_domains(question:str)->List[str]:
    q=question.lower(); out=[d for d,terms in DOMAIN_TERMS.items() if any(t in q for t in terms)]
    return out or ["general"]

def select_facts(question:str, facts:Iterable[Dict[str,Any]], limit:int=12)->List[Dict[str,Any]]:
    q=question.lower(); domains=infer_domains(question); scored=[]
    for f in facts:
        if f.get("status") not in {"APPROVED","VERIFIED"}: continue
        value=str(f.get("value") or "").strip()
        if not value: continue
        hay=" ".join([str(f.get("fact_key","")),str(f.get("category","")),value]).lower()
        score=sum(3 for d in domains if d!="general" and d in hay)
        score+=sum(1 for word in set(re.findall(r"[a-z]{4,}",q)) if word in hay)
        if score>0 or domains==["general"]: scored.append((score,f))
    scored.sort(key=lambda x:(x[0],x[1].get("status")=="VERIFIED"),reverse=True)
    return [f for _,f in scored[:limit]]

def _deterministic(question:str, selected:List[Dict[str,Any]])->str:
    if not selected:
        return "Insufficient approved or verified organizational information is available to answer this grant question without guessing."
    sentences=[]
    for f in selected:
        v=str(f["value"]).strip()
        if v and v[-1] not in ".!?": v+="."
        if v not in sentences: sentences.append(v)
    return " ".join(sentences)

def _ollama(question:str, selected:List[Dict[str,Any]])->str:
    if not OLLAMA_MODEL: raise RuntimeError("GRANTBOT_OLLAMA_MODEL is not configured")
    facts=[{"fact_key":f["fact_key"],"status":f["status"],"value":f["value"]} for f in selected]
    prompt=("Answer the grant question using ONLY the supplied facts. Do not invent numbers, partners, outcomes, dates, legal status, services, or accomplishments. "
            "If facts are insufficient, explicitly say what cannot be established. Distinguish planned activities from current activities exactly as the facts do.\n\n"
            f"QUESTION:\n{question}\n\nFACTS:\n{json.dumps(facts,ensure_ascii=False,indent=2)}")
    r=requests.post(f"{OLLAMA_URL}/api/generate",json={"model":OLLAMA_MODEL,"prompt":prompt,"stream":False},timeout=HTTP_TIMEOUT)
    r.raise_for_status(); data=r.json(); text=str(data.get("response") or "").strip()
    if not text: raise RuntimeError("Ollama returned an empty response")
    return text

def write_grant_answer(question:str, facts:Iterable[Dict[str,Any]], use_ollama:bool=False)->Dict[str,Any]:
    selected=select_facts(question,facts)
    narrative=_ollama(question,selected) if use_ollama else _deterministic(question,selected)
    claims=check_claims(narrative,selected)
    verification_needed=[] if selected else ["Approved or verified facts relevant to this question"]
    return {"question":question,"narrative":narrative,"facts_used":[f["fact_key"] for f in selected],"verification_needed":verification_needed,"unsupported_claims":claims["unsupported_claims"],"safe_to_submit":bool(selected) and claims["safe"],"domains":infer_domains(question)}
