from __future__ import annotations
import re
from typing import Any, Dict, Iterable, List

def normalize(s:str)->str:
    return re.sub(r"\s+"," ",(s or "").strip().lower())

def check_claims(narrative:str, facts:Iterable[Dict[str,Any]])->Dict[str,Any]:
    narrative=(narrative or "").strip()
    fact_values=[str(f.get("value","")).strip() for f in facts if f.get("status") in {"APPROVED","VERIFIED"} and f.get("value") not in (None,"")]
    unsupported=[]
    # High-risk concrete assertions: numbers, money, percentages, named partners and dates must appear in approved/verified facts.
    concrete=set(re.findall(r"\$?\b\d[\d,]*(?:\.\d+)?%?\b", narrative))
    corpus=" ".join(fact_values)
    for token in sorted(concrete):
        if token not in corpus: unsupported.append(f"Unsupported concrete value: {token}")
    safe=not unsupported
    return {"safe":safe,"unsupported_claims":unsupported,"facts_checked":len(fact_values)}
