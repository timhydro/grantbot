from __future__ import annotations
import json
from typing import Any, Dict, Iterable, List, Optional
from grantbot.data.db import connect, init_db, now, audit

VALID_STATUS = {"APPROVED","VERIFIED","DRAFT","MISSING"}
VALID_PROVENANCE = {"FOUNDER_FACT","DOCUMENT_FACT","OFFICIAL_SOURCE","CALCULATION","INFERENCE","DRAFT_LANGUAGE"}

class KnowledgeStore:
    def __init__(self):
        init_db()

    def add_source(self, source_key: str, title: str, source_type: str, location: str | None = None, citation: str | None = None, verified: bool = False) -> None:
        if not source_key.strip() or not title.strip() or not source_type.strip():
            raise ValueError("source_key, title and source_type are required")
        with connect() as con:
            con.execute("""INSERT INTO sources(source_key,title,source_type,location,citation,verified,created_at)
                         VALUES(?,?,?,?,?,?,?) ON CONFLICT(source_key) DO UPDATE SET title=excluded.title,source_type=excluded.source_type,location=excluded.location,citation=excluded.citation,verified=excluded.verified""",
                        (source_key.strip(), title.strip(), source_type.strip(), location, citation, int(verified), now()))

    def set_fact(self, fact_key: str, category: str, value: Any, status: str, provenance: str, source_key: str | None = None, reusable: bool = True, sensitive: bool = False) -> int:
        if status not in VALID_STATUS: raise ValueError(f"Invalid status: {status}")
        if provenance not in VALID_PROVENANCE: raise ValueError(f"Invalid provenance: {provenance}")
        if not fact_key.strip() or not category.strip(): raise ValueError("fact_key and category are required")
        if status != "MISSING" and (value is None or (isinstance(value, str) and not value.strip())):
            raise ValueError("Non-MISSING facts require a value")
        with connect() as con:
            con.execute("UPDATE facts SET valid_to=? WHERE fact_key=? AND valid_to IS NULL", (now(), fact_key))
            cur = con.execute("""INSERT INTO facts(fact_key,category,value_json,status,provenance,reusable,sensitive,source_key,valid_from,created_at)
                               VALUES(?,?,?,?,?,?,?,?,?,?)""",
                              (fact_key.strip(), category.strip(), json.dumps(value, ensure_ascii=False), status, provenance, int(reusable), int(sensitive), source_key, now(), now()))
            fact_id = int(cur.lastrowid)
        audit("fact_set", f"Set {fact_key} as {status}", "fact", str(fact_id), {"fact_key":fact_key,"status":status})
        return fact_id

    def get_fact(self, fact_key: str, allowed_statuses: Iterable[str] = ("APPROVED","VERIFIED")) -> Dict[str, Any] | None:
        statuses = tuple(allowed_statuses)
        if not statuses: return None
        marks = ",".join("?" for _ in statuses)
        with connect() as con:
            row = con.execute(f"SELECT * FROM facts WHERE fact_key=? AND valid_to IS NULL AND status IN ({marks}) ORDER BY id DESC LIMIT 1", (fact_key,*statuses)).fetchone()
        return self._row(row) if row else None

    def list_facts(self, category: str | None = None, allowed_statuses: Iterable[str] = ("APPROVED","VERIFIED"), reusable_only: bool = True) -> List[Dict[str, Any]]:
        statuses = tuple(allowed_statuses)
        marks = ",".join("?" for _ in statuses)
        sql = f"SELECT * FROM facts WHERE valid_to IS NULL AND status IN ({marks})"
        params:list[Any] = list(statuses)
        if category:
            sql += " AND category=?"; params.append(category)
        if reusable_only: sql += " AND reusable=1"
        sql += " ORDER BY category,fact_key,id DESC"
        with connect() as con: rows = con.execute(sql, params).fetchall()
        return [self._row(r) for r in rows]

    def missing(self, category: str | None = None) -> List[Dict[str, Any]]:
        sql = "SELECT * FROM facts WHERE valid_to IS NULL AND status='MISSING'"
        params=[]
        if category: sql += " AND category=?"; params.append(category)
        with connect() as con: rows=con.execute(sql+" ORDER BY category,fact_key",params).fetchall()
        return [self._row(r) for r in rows]

    @staticmethod
    def _row(row) -> Dict[str, Any]:
        d=dict(row); d["value"]=json.loads(d.pop("value_json")); d["reusable"]=bool(d["reusable"]); d["sensitive"]=bool(d["sensitive"]); return d
