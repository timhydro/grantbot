from __future__ import annotations
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()
BASE_DIR = Path(__file__).resolve().parents[2]
DB_PATH = Path(os.getenv("GRANTBOT_DB_PATH", str(BASE_DIR / "grantbot.db"))).expanduser().resolve()
HTTP_TIMEOUT = max(5, int(os.getenv("GRANTBOT_HTTP_TIMEOUT", "30")))
OLLAMA_URL = os.getenv("GRANTBOT_OLLAMA_URL", "http://127.0.0.1:11434").rstrip("/")
OLLAMA_MODEL = os.getenv("GRANTBOT_OLLAMA_MODEL", "").strip()
