"""Vercel and WSGI entry point."""

from grantbot.app import create_app

app = create_app()
