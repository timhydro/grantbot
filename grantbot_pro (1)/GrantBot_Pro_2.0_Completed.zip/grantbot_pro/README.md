# GrantBot Pro 2.0

GrantBot Pro is a fact-controlled Flask application customized for Broken Growth Ministries. It stores versioned organization answers, maps funder requirements to the knowledge base, drafts only from verified inputs, and flags missing or unverified information before submission.

## What works

- Broken Growth owner-confirmed profile seed with current and planned programs separated
- versioned facts with source, provenance, verification state, and verification date
- missing-information and grant-requirement analysis
- factual, enhanced, and clearly labeled creative-draft modes
- fact ledger on every draft and conservative `safe_to_submit` gate
- word, character, and required-concept compliance checks
- budget total reconciliation
- historical-outcome ML with checksum-protected model loading
- API validation, request-size limit, API-key protection, security headers, and audit events
- browser dashboard, CLI, SQLite development storage, PostgreSQL production support
- Vercel-compatible WSGI entry point and configuration
- 26 automated tests

Every generated response still requires human review. The software cannot verify an external fact unless its supporting organizational record has been entered and approved.

## Chromebook/Linux installation

```bash
chmod +x bootstrap.sh
./bootstrap.sh
source .venv/bin/activate
python run.py
```

Open `http://127.0.0.1:5000`.

The bootstrap script creates local secrets, initializes the database, seeds the approved Broken Growth profile, and runs all tests.

## Commands

```bash
python -m grantbot.cli status
python -m grantbot.cli missing
python -m grantbot.cli verification-needed
python -m grantbot.cli answer ORG_EIN "verified value"
python -m pytest -q
```

CLI answers default to unverified. Use the API with explicit source and verification metadata when entering document-backed facts.

## Important API routes

| Method | Route | Purpose |
|---|---|---|
| GET | `/health` | runtime and storage status |
| GET | `/api/profile/status` | overall and verified completion |
| GET | `/api/profile/missing?required_only=1&verified_only=1` | unresolved questions |
| GET | `/api/profile/verification-needed` | records still needed from Broken Growth |
| POST | `/api/profile/answer` | save a versioned fact |
| POST | `/api/analyze/requirement` | map a funder prompt to facts and gaps |
| POST | `/api/draft` | generate a controlled draft with fact ledger |
| POST | `/api/compliance` | check limits and required concepts |
| POST | `/api/budget/reconcile` | reconcile line items to narrative total |
| POST | `/api/readiness` | extract readiness features and optional trained prediction |

When `GRANTBOT_REQUIRE_API_KEY=1`, send the secret in the `X-GrantBot-Key` header.

## Verified-fact workflow

Use these provenance values:

- `USER_FACT`: confirmed directly by the organization owner
- `DOCUMENT_FACT`: supported by an organizational or authoritative record
- `CALCULATION`: reproducible calculation from cited inputs
- `INFERENCE`: analytical conclusion requiring review
- `CREATIVE_LANGUAGE`: non-factual persuasive wording
- `PLACEHOLDER`: incomplete material that cannot be submitted

New answers default to `verified=false`. Unverified values are not used as drafting context. Creative drafts are never marked safe to submit.

## Vercel deployment

Vercel recognizes the root `app.py` as the Flask WSGI entry point. Configure these environment variables before production use:

```text
GRANTBOT_SECRET_KEY=<long random secret>
GRANTBOT_API_KEY=<long random API key>
GRANTBOT_REQUIRE_API_KEY=1
GRANTBOT_SEED_PROFILE=1
GRANTBOT_DATABASE_URL=postgresql://USER:PASSWORD@HOST/DATABASE
```

If no production database is configured on Vercel, the app falls back to `/tmp/grantbot.db`. That keeps the function runnable but the data is ephemeral. Use managed PostgreSQL for durable facts, proposals, and audit history.

Deploy from the project root:

```bash
vercel
```

## Records still required

Run `python -m grantbot.cli verification-needed`. The list includes the exact legal name, EIN, formation record, IRS status evidence, budget and bank records, outcomes, signed partnerships, employment details, site control/zoning, policies, insurance, and permits.

See `AUDIT_REPORT.md` for the completed repair summary and production priorities.
