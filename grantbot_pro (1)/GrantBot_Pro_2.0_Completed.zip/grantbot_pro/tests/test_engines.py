from grantbot.analysis import AnswerSufficiencyEngine, RequirementMapper
from grantbot.budget import BudgetEngine
from grantbot.compliance import ComplianceEngine, ConsistencyEngine
from grantbot.ml import GrantMLEngine


def test_sufficiency_scores_and_gaps():
    result = AnswerSufficiencyEngine().score("Short answer", ["housing"])
    assert result["score"] < 50
    assert "more specificity" in result["gaps"]
    assert "direct coverage of required concepts" in result["gaps"]


def test_requirement_mapper_covers_program_domains():
    mapped = RequirementMapper().map("Explain the reentry housing and workforce program")
    assert "ORG_POPULATION_SERVED" in mapped
    assert "ORG_PROGRAMS_PLANNED" in mapped
    assert "PARTNERS_CURRENT" in mapped


def test_budget_detects_missing_total():
    result = BudgetEngine().reconcile("We request funding.", [{"amount": 100}])
    assert result["narrative_contains_total"] is False
    assert result["issues"]


def test_compliance_limits():
    result = ComplianceEngine().check("one two three", word_limit=2, character_limit=5)
    assert result["passed"] is False
    assert len(result["issues"]) == 2


def test_consistency_extracts_numeric_mentions():
    result = ConsistencyEngine().compare({"need": "Serve 30 people", "budget": "$30"})
    assert "30" in result["numeric_mentions"]


def test_ml_model_requires_checksum_and_round_trips(tmp_path):
    path = tmp_path / "model.pkl"
    engine = GrantMLEngine(path)
    engine.add_training_sample("housing impact 10", 0.2)
    engine.add_training_sample("housing employment measurable outcomes 100", 0.8)
    assert engine.train() is True
    assert path.exists()
    assert path.with_suffix(".pkl.sha256").exists()
    loaded = GrantMLEngine(path)
    assert loaded.model is not None
    assert loaded.predict("housing employment") is not None


def test_ml_refuses_tampered_pickle(tmp_path):
    path = tmp_path / "model.pkl"
    path.write_bytes(b"not a safe model")
    path.with_suffix(".pkl.sha256").write_text("incorrect", encoding="ascii")
    assert GrantMLEngine(path).model is None
