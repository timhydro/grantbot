from grantbot.app import create_app


def test_health_and_security_headers(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json["status"] == "ok"
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    assert response.headers["Cache-Control"] == "no-store"


def test_status(client):
    response = client.get("/api/profile/status")
    assert response.status_code == 200
    assert response.json["verified_required_completion_percent"] == 0.0


def test_answer_defaults_to_unverified(client):
    response = client.post("/api/profile/answer", json={
        "question_id": "ORG_MISSION",
        "value": "We strengthen communities through housing and opportunity.",
    })
    assert response.status_code == 201
    assert response.json["verified"] is False
    profile = client.get("/api/profile").json
    assert profile["ORG_MISSION"]["answer"]
    assert profile["ORG_MISSION"]["verified"] is False


def test_answer_round_trip_with_provenance(client):
    response = client.post("/api/profile/answer", json={
        "question_id": "ORG_MISSION",
        "value": "A verified mission statement.",
        "source": "board-approved policy",
        "provenance": "DOCUMENT_FACT",
        "verified": True,
    })
    assert response.status_code == 201
    profile = client.get("/api/profile").json["ORG_MISSION"]
    assert profile["source"] == "board-approved policy"
    assert profile["provenance"] == "DOCUMENT_FACT"
    assert profile["verified"] is True


def test_unknown_question_is_validation_error(client):
    response = client.post("/api/profile/answer", json={"question_id": "FAKE", "value": "x"})
    assert response.status_code == 400
    assert response.json["error"] == "validation_error"


def test_empty_and_malformed_requests_are_400(client):
    assert client.post("/api/draft", json={"prompt": ""}).status_code == 400
    assert client.post("/api/draft", data="not json", content_type="text/plain").status_code == 400
    assert client.post("/api/profile/answer", json={"question_id": "ORG_MISSION"}).status_code == 400


def test_api_key_protection(tmp_path):
    app = create_app({
        "TESTING": True,
        "SEED_PROFILE": False,
        "REQUIRE_API_KEY": True,
        "API_KEY": "correct-key",
        "SQLALCHEMY_DATABASE_URI": f"sqlite:///{tmp_path / 'auth.db'}",
    })
    client = app.test_client()
    assert client.get("/api/profile/status").status_code == 401
    assert client.get("/api/profile/status", headers={"X-GrantBot-Key": "wrong"}).status_code == 401
    assert client.get("/api/profile/status", headers={"X-GrantBot-Key": "correct-key"}).status_code == 200


def test_requirement_analysis_flags_missing_and_unverified(client):
    client.post("/api/profile/answer", json={
        "question_id": "ORG_MISSION", "value": "Unverified mission"
    })
    result = client.post("/api/analyze/requirement", json={
        "prompt": "Describe the organization mission and history."
    }).json
    assert "ORG_MISSION" in result["unverified_question_ids"]
    assert "ORG_HISTORY" in result["missing_question_ids"]
    assert result["ready"] is False


def test_draft_uses_only_verified_facts(client):
    client.post("/api/profile/answer", json={
        "question_id": "ORG_MISSION",
        "value": "Verified mission",
        "verified": True,
        "source": "owner",
    })
    result = client.post("/api/draft", json={
        "prompt": "What is your mission?",
        "answer": "Unsupported claim of serving 10,000 people.",
    }).json
    assert "Verified mission" in result["draft"]
    assert "10,000" not in result["draft"]
    assert result["facts_used"][0]["verified"] is True
    assert "APPLICANT_DRAFT_INPUT" in result["unverified_information"]
    assert result["safe_to_submit"] is False


def test_verified_draft_can_pass_system_checks(client):
    client.post("/api/profile/answer", json={
        "question_id": "ORG_MISSION",
        "value": "Verified mission",
        "verified": True,
    })
    result = client.post("/api/draft", json={
        "prompt": "What is your mission?",
        "answer": "Verified mission",
        "answer_verified": True,
        "mode": "factual",
    }).json
    assert result["safe_to_submit"] is True
    assert result["human_review_required"] is True
    assert result["facts_used"][-1]["question_id"] == "APPLICANT_DRAFT_INPUT"


def test_organization_word_does_not_overmap_mission_prompt(client):
    client.post("/api/profile/answer", json={
        "question_id": "ORG_MISSION", "value": "Verified mission", "verified": True
    })
    result = client.post("/api/draft", json={
        "prompt": "What is your organization mission?", "mode": "enhanced"
    }).json
    assert result["missing_information"] == []
    assert [fact["question_id"] for fact in result["facts_used"]] == ["ORG_MISSION"]
    assert result["draft"].startswith("The work is closely connected")


def test_creative_mode_never_marked_safe(client):
    result = client.post("/api/draft", json={
        "prompt": "Write an opening statement.", "mode": "creative_draft"
    }).json
    assert result["safe_to_submit"] is False
    assert "Creative placeholders require human review." in result["compliance"]["issues"]


def test_program_draft_uses_available_facts_while_flagging_gaps(client):
    client.post("/api/profile/answer", json={
        "question_id": "ORG_PROGRAMS",
        "value": "Verified current program activity.",
        "verified": True,
    })
    result = client.post("/api/draft", json={
        "prompt": "Describe your employment and workforce program."
    }).json
    assert "Verified current program activity." in result["draft"]
    assert "OUTCOMES_CURRENT" in result["missing_information"]
    assert result["safe_to_submit"] is False


def test_invalid_draft_mode_is_400(client):
    response = client.post("/api/draft", json={"prompt": "Mission", "mode": "invent"})
    assert response.status_code == 400


def test_budget_endpoint(client):
    result = client.post("/api/budget/reconcile", json={
        "narrative": "The total request is $3,000.00.",
        "items": [{"name": "Housing", "amount": 2000}, {"name": "Training", "amount": 1000}],
    }).json
    assert result["budget_total"] == 3000.0
    assert result["narrative_contains_total"] is True
    assert result["issues"] == []


def test_invalid_budget_is_400(client):
    response = client.post("/api/budget/reconcile", json={"items": [{"amount": -1}]})
    assert response.status_code == 400


def test_compliance_endpoint(client):
    result = client.post("/api/compliance", json={
        "text": "housing and employment", "required_terms": ["housing", "outcomes"]
    }).json
    assert result["passed"] is False
    assert result["missing_terms"] == ["outcomes"]


def test_broken_growth_seed_has_no_invented_legal_or_financial_values(tmp_path):
    app = create_app({
        "TESTING": True,
        "SEED_PROFILE": True,
        "REQUIRE_API_KEY": False,
        "SQLALCHEMY_DATABASE_URI": f"sqlite:///{tmp_path / 'seed.db'}",
    })
    profile = app.test_client().get("/api/profile").json
    assert profile["ORG_PUBLIC_NAME"]["answer"] == "Broken Growth Ministries"
    assert profile["ORG_EIN"]["answer"] is None
    assert profile["FIN_ANNUAL_BUDGET"]["answer"] is None
    assert "planned" in profile["ORG_PROGRAMS_PLANNED"]["answer"].lower()
    assert "small-scale" in profile["ORG_PROGRAMS"]["answer"].lower()


def test_verification_needed_endpoint(client):
    result = client.get("/api/profile/verification-needed").json
    assert len(result["items"]) >= 10
    assert any("EIN" in item for item in result["items"])
