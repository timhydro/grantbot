import os
import tempfile

import pytest

from grantbot.app import create_app
from grantbot.db import db


@pytest.fixture()
def app():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    app = create_app({
        "TESTING": True,
        "SEED_PROFILE": False,
        "REQUIRE_API_KEY": False,
        "SQLALCHEMY_DATABASE_URI": f"sqlite:///{path}",
    })
    yield app
    with app.app_context():
        db.session.remove()
        db.engine.dispose()
    os.unlink(path)


@pytest.fixture()
def client(app):
    return app.test_client()
