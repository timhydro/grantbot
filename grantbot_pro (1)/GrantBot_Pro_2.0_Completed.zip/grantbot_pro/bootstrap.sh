#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements-dev.txt
[ -f .env ] || cp .env.example .env
secret_key="$(python -c 'import secrets; print(secrets.token_urlsafe(48))')"
api_key="$(python -c 'import secrets; print(secrets.token_urlsafe(32))')"
sed -i "s|^GRANTBOT_SECRET_KEY=$|GRANTBOT_SECRET_KEY=${secret_key}|" .env
sed -i "s|^GRANTBOT_API_KEY=$|GRANTBOT_API_KEY=${api_key}|" .env
python -m grantbot.cli init
python -m pytest -q
echo "GrantBot Pro initialized and tested. Run: source .venv/bin/activate && python -m grantbot.app"
