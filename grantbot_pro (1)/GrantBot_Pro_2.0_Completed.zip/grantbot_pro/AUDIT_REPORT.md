# GrantBot Pro Audit — 2026-08-13

## Completed repairs

| Risk found | Repair completed |
|---|---|
| New claims defaulted to verified | New facts now default to unverified and require explicit verification |
| Drafts had no fact ledger | Draft responses now return exact facts, sources, provenance, and verification state |
| Unverified input could enter drafts | Unverified profile and applicant inputs are excluded and flagged |
| Missing facts were not part of draft safety | Missing and unverified question IDs now block `safe_to_submit` |
| Planned programs could be presented as current | Current small-scale assistance and planned full programs are stored separately |
| API input errors could become server errors | JSON, type, limit, enum, and budget validation now return controlled 400 responses |
| API had no access control | Optional API-key enforcement uses constant-time comparison and is enabled by default on Vercel |
| No request/security protections | Added 1 MiB request limit, no-store policy, anti-sniffing, frame denial, and safe error responses |
| Budget/compliance engines were unreachable | Added tested API endpoints |
| Pickled ML model could be loaded without integrity proof | Model files now require a matching SHA-256 sidecar |
| Deprecated UTC timestamps | Replaced with timezone-aware UTC timestamps |
| No real browser UI | Added a responsive operational dashboard |
| No Vercel entry point | Added root WSGI `app.py`, Python 3.12 metadata, PostgreSQL driver, and `vercel.json` |
| Only two tests | Expanded to 26 passing tests across the core workflow |

## Highest-priority production upgrades still requiring external setup

1. Configure managed PostgreSQL before storing real organizational or applicant data on Vercel.
2. Replace shared API-key access with named user accounts, roles, session expiry, and audit attribution.
3. Add encrypted document storage and document-backed verification approvals.
4. Add official NOFO ingestion, eligibility hard gates, deadlines, and citation capture.
5. Add a production LLM provider with structured output, retry limits, cost controls, and prompt-injection defenses.
6. Add proposal/project CRUD, exports, backups, database migrations, and disaster recovery.
7. Add structured production logs and error monitoring without recording sensitive applicant data.

## Verified organizational-data rule

The included seed contains only owner-confirmed facts from the supplied project context. It deliberately omits exact legal, tax, financial, partnership, outcome, employment, land-control, and regulatory claims that lack supporting records. Those items remain visible in the verification-needed endpoint and CLI command.
