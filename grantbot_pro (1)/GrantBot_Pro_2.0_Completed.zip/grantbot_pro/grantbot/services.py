import json
from .db import db
from .models import AuditEvent
from .knowledge import KnowledgeBase
from .analysis import RequirementMapper, AnswerSufficiencyEngine
from .writer import GrantWriter
from .compliance import ComplianceEngine, ConsistencyEngine
from .budget import BudgetEngine
from .ml import GrantMLEngine

class GrantBotService:
    def __init__(self):
        self.kb = KnowledgeBase()
        self.mapper = RequirementMapper()
        self.sufficiency = AnswerSufficiencyEngine()
        self.writer = GrantWriter()
        self.compliance = ComplianceEngine()
        self.consistency = ConsistencyEngine()
        self.budget = BudgetEngine()
        self.ml = GrantMLEngine()

    def audit(self, event_type, message, entity_type=None, entity_id=None, data=None):
        db.session.add(AuditEvent(
            event_type=event_type,
            entity_type=entity_type,
            entity_id=str(entity_id) if entity_id is not None else None,
            message=message,
            data_json=json.dumps(data or {}, default=str),
        ))
        db.session.commit()

    def analyze_requirement(self, prompt, category="other"):
        mapped = self.mapper.map(prompt, category)
        missing = []
        unverified = []
        for qid in mapped:
            record = self.kb.get_record(qid)
            if record is None:
                missing.append(qid)
            elif not record.verified:
                unverified.append(qid)
        return {
            "mapped_question_ids": mapped,
            "missing_question_ids": missing,
            "unverified_question_ids": unverified,
            "ready": not missing and not unverified,
        }

    def draft(self, prompt, answer="", mode="enhanced", answer_verified=False,
              word_limit=None, character_limit=None, required_terms=None):
        requirement = self.analyze_requirement(prompt)
        mapped = requirement["mapped_question_ids"]
        context = self.kb.context(mapped, verified_only=True)
        facts_used = self.kb.fact_records(mapped, verified_only=True)
        unverified = list(requirement["unverified_question_ids"])
        source_answer = (answer or "").strip()
        if source_answer and not answer_verified:
            unverified.append("APPLICANT_DRAFT_INPUT")
            source_answer = ""
        elif source_answer:
            facts_used.append({
                "question_id": "APPLICANT_DRAFT_INPUT",
                "value": source_answer,
                "source": "request",
                "provenance": "USER_FACT",
                "verified": True,
                "last_verified": None,
            })
        result = self.writer.draft_section(prompt, source_answer, context, mode)
        compliance = self.compliance.submission_check(
            result,
            missing_question_ids=requirement["missing_question_ids"],
            unverified_question_ids=unverified,
            word_limit=word_limit,
            character_limit=character_limit,
            required_terms=required_terms,
        )
        creative_review = mode == "creative_draft"
        if creative_review:
            compliance["issues"].append("Creative placeholders require human review.")
            compliance["passed"] = False
        return {
            "draft": result,
            "mode": mode,
            "facts_used": facts_used,
            "missing_information": requirement["missing_question_ids"],
            "unverified_information": list(dict.fromkeys(unverified)),
            "compliance": compliance,
            "safe_to_submit": compliance["passed"] and not creative_review,
            "human_review_required": True,
        }

    def readiness(self, text, requirement_metrics=None):
        metrics = requirement_metrics or {}
        features = self.ml.extract_features(text, metrics=metrics)
        score = self.ml.predict(text, metrics=metrics)
        return {"prediction": score, "features": features, "feature_importance": self.ml.feature_importance()}

    def budget_check(self, narrative, items):
        return self.budget.reconcile(narrative, items)

    def compliance_check(self, text, **limits):
        return self.compliance.check(text, **limits)
