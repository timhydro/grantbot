from datetime import datetime, timezone


def utc_now():
    """Return a timezone-aware UTC timestamp for persisted records."""
    return datetime.now(timezone.utc)


def utc_iso(value):
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).isoformat()
