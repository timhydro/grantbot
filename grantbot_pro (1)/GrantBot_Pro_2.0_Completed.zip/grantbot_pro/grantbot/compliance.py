import re

class ComplianceEngine:
    def check(self, text, word_limit=None, character_limit=None, required_terms=None):
        words = len(text.split())
        chars = len(text)
        issues = []
        if word_limit and words > word_limit:
            issues.append(f"Word limit exceeded by {words-word_limit} words.")
        if character_limit and chars > character_limit:
            issues.append(f"Character limit exceeded by {chars-character_limit} characters.")
        missing = []
        for term in required_terms or []:
            if term.lower() not in text.lower():
                missing.append(term)
        if missing:
            issues.append("Missing required concepts: " + ", ".join(missing))
        return {
            "passed": not issues,
            "word_count": words,
            "character_count": chars,
            "issues": issues,
            "missing_terms": missing,
        }

    def submission_check(self, text, missing_question_ids=None, unverified_question_ids=None,
                         word_limit=None, character_limit=None, required_terms=None):
        result = self.check(text, word_limit, character_limit, required_terms)
        missing = list(dict.fromkeys(missing_question_ids or []))
        unverified = list(dict.fromkeys(unverified_question_ids or []))
        if missing:
            result["issues"].append(
                "Missing organizational information: " + ", ".join(missing)
            )
        if unverified:
            result["issues"].append(
                "Unverified organizational information: " + ", ".join(unverified)
            )
        result["missing_question_ids"] = missing
        result["unverified_question_ids"] = unverified
        result["passed"] = not result["issues"]
        return result

class ConsistencyEngine:
    def compare(self, sections):
        numbers = {}
        conflicts = []
        for name, text in sections.items():
            for token in re.findall(r"(?<!\w)\d+(?:\.\d+)?(?:\s*[%$])?", text or ""):
                numbers.setdefault(token, []).append(name)
        # Flag repeated numeric values only as a review aid; semantic contradiction
        # requires a stronger document/NLP layer.
        return {"numeric_mentions": numbers, "conflicts": conflicts}
