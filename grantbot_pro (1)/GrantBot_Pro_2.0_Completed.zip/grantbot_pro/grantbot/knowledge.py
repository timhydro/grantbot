from .db import db
from .models import MasterAnswer
from .questions import MASTER_QUESTIONS
from .timeutils import utc_iso, utc_now


ALLOWED_PROVENANCE = {
    "USER_FACT",
    "DOCUMENT_FACT",
    "CALCULATION",
    "INFERENCE",
    "CREATIVE_LANGUAGE",
    "PLACEHOLDER",
}

class KnowledgeBase:
    def __init__(self):
        self.questions = {
            q[0]: {
                "id": q[0], "category": q[1], "question": q[2],
                "type": q[3], "required": q[4], "reusable": True
            } for q in MASTER_QUESTIONS
        }

    def get(self, question_id):
        answer = self.get_record(question_id)
        return answer.value if answer else None

    def get_record(self, question_id):
        return (MasterAnswer.query
                .filter_by(question_id=question_id, valid_to=None)
                .order_by(MasterAnswer.updated_at.desc())
                .first())

    def set(self, question_id, value, source="user",
            provenance="USER_FACT", verified=False, reusable=True):
        if question_id not in self.questions:
            raise ValueError(f"Unknown question ID: {question_id}")
        if not isinstance(provenance, str) or provenance not in ALLOWED_PROVENANCE:
            raise ValueError(f"Unsupported provenance: {provenance}")
        if value is None or not str(value).strip():
            raise ValueError("Answer value cannot be empty.")
        if not source or not str(source).strip():
            raise ValueError("Answer source cannot be empty.")
        old = self.get_record(question_id)
        if old:
            old.valid_to = utc_now()
        answer = MasterAnswer(
            question_id=question_id,
            value=str(value).strip(),
            answer_type=self.questions[question_id]["type"],
            source=str(source).strip(),
            provenance=provenance,
            verified=bool(verified),
            reusable=bool(reusable),
            last_verified=utc_now() if verified else None,
        )
        db.session.add(answer)
        db.session.commit()
        return answer

    def missing(self, required_only=False, verified_only=False):
        result = []
        for q in self.questions.values():
            if required_only and not q["required"]:
                continue
            record = self.get_record(q["id"])
            if record is None or (verified_only and not record.verified):
                result.append(q)
        return result

    def status(self):
        total = len(self.questions)
        answered = total - len(self.missing())
        required = len([q for q in self.questions.values() if q["required"]])
        required_missing = len(self.missing(True))
        verified_required_missing = len(self.missing(True, verified_only=True))
        return {
            "total": total,
            "answered": answered,
            "remaining": total - answered,
            "completion_percent": round(answered / total * 100, 1) if total else 100,
            "required": required,
            "required_remaining": required_missing,
            "verified_required_remaining": verified_required_missing,
            "required_completion_percent":
                round((required - required_missing) / required * 100, 1) if required else 100,
            "verified_required_completion_percent":
                round((required - verified_required_missing) / required * 100, 1) if required else 100,
        }

    def context(self, question_ids=None, verified_only=True):
        ids = question_ids or list(self.questions)
        result = {}
        for qid in ids:
            record = self.get_record(qid)
            if record and (record.verified or not verified_only):
                result[qid] = record.value
        return result

    def fact_records(self, question_ids=None, verified_only=True):
        ids = question_ids or list(self.questions)
        records = []
        for qid in ids:
            record = self.get_record(qid)
            if not record or (verified_only and not record.verified):
                continue
            records.append({
                "question_id": qid,
                "value": record.value,
                "source": record.source,
                "provenance": record.provenance,
                "verified": record.verified,
                "last_verified": utc_iso(record.last_verified),
            })
        return records

    def seed(self, facts, overwrite=False):
        saved = []
        skipped = []
        for question_id, payload in facts.items():
            if self.get_record(question_id) and not overwrite:
                skipped.append(question_id)
                continue
            record = self.set(question_id=question_id, **payload)
            saved.append(record.question_id)
        return {"saved": saved, "skipped": skipped}

    def export(self):
        result = {}
        for qid, q in self.questions.items():
            record = self.get_record(qid)
            result[qid] = {
                "question": q["question"],
                "required": q["required"],
                "answer": record.value if record else None,
                "source": record.source if record else None,
                "provenance": record.provenance if record else None,
                "verified": record.verified if record else False,
                "last_verified": utc_iso(record.last_verified) if record else None,
            }
        return result
