import re


ALLOWED_DRAFT_MODES = {"factual", "enhanced", "creative_draft"}

class AnswerSufficiencyEngine:
    """Scores completeness without pretending that a score is factual truth."""

    def score(self, answer, expected_terms=None):
        answer = (answer or "").strip()
        words = len(answer.split())
        specificity = min(1.0, words / 120.0)
        structure = 1.0 if any(x in answer for x in [".", ";", "\n"]) else 0.4
        evidence = 1.0 if re.search(r"\d|according to|report|study|data|survey", answer, re.I) else 0.25
        relevance = 1.0
        if expected_terms:
            hits = sum(1 for term in expected_terms if term.lower() in answer.lower())
            relevance = hits / max(1, len(expected_terms))
        score = round((specificity*.30 + structure*.15 + evidence*.25 + relevance*.30) * 100, 1)
        gaps = []
        if words < 25: gaps.append("more specificity")
        if evidence < .5: gaps.append("supporting evidence or clearly labeled context")
        if expected_terms and relevance < .6: gaps.append("direct coverage of required concepts")
        return {"score": score, "gaps": gaps, "word_count": words}

class PersuasionEngine:
    """
    Produces an enhancement brief rather than silently fabricating facts.
    Supports factual, enhanced, and creative-draft workflows.
    """

    def build_brief(self, answer, requirement, mode="enhanced"):
        if mode not in ALLOWED_DRAFT_MODES:
            raise ValueError(f"Unsupported drafting mode: {mode}")
        analysis = AnswerSufficiencyEngine().score(answer)
        return {
            "mode": mode,
            "original": answer,
            "requirement": requirement,
            "recommended_structure": [
                "lead with the problem or human significance",
                "connect the problem to the proposed response",
                "use concrete details and measurable outcomes where available",
                "show organizational credibility",
                "close with funder-aligned impact",
            ],
            "gaps": analysis["gaps"],
            "provenance_policy": "label material assumptions/placeholders for review",
        }

    def enhance(self, answer, requirement, context=None, mode="enhanced"):
        self.build_brief(answer, requirement, mode)
        context = context or {}
        lead = answer.strip()
        if mode == "factual":
            values = [lead] if lead else []
            values.extend(value for value in context.values() if value and value not in values)
            return "\n\n".join(values)
        # Deterministic local fallback. Production LLM providers can replace this.
        parts = [lead] if lead else []
        if context.get("ORG_MISSION"):
            parts.append(f"The work is closely connected to the organization's mission: {context['ORG_MISSION']}")
        for question_id, value in context.items():
            if question_id == "ORG_MISSION" or not value:
                continue
            if question_id == "NEED_EVIDENCE":
                parts.append(f"Available supporting evidence includes: {value}")
            elif question_id == "OUTCOMES_CURRENT":
                parts.append(f"Relevant demonstrated outcomes include: {value}")
            else:
                parts.append(value)
        if mode == "creative_draft":
            parts.append("[Add a specific human-centered example or story here.]")
        return "\n\n".join(dict.fromkeys(parts))

class RequirementMapper:
    def map(self, prompt, category="other"):
        p = prompt.lower()
        ids = []
        from .questions import QUESTION_MAP
        if category in QUESTION_MAP:
            ids.extend(QUESTION_MAP[category])
        keyword_map = {
            "mission": ["ORG_MISSION"],
            "history": ["ORG_HISTORY"],
            "need": ["NEED_PRIMARY_PROBLEM","NEED_WHO_AFFECTED","NEED_SCOPE","NEED_EVIDENCE"],
            "outcome": ["OUTCOMES_CURRENT","EVALUATION_METHOD"],
            "evaluation": ["EVALUATION_METHOD","EVALUATION_DATA"],
            "sustain": ["SUSTAINABILITY","SUSTAINABILITY_REVENUE"],
            "partner": ["PARTNERS_CURRENT","PARTNERS_ROLES"],
            "budget": ["FIN_ANNUAL_BUDGET","FIN_EXPENSES","FIN_REVENUE"],
            "employment": ["ORG_PROGRAMS","ORG_PROGRAMS_PLANNED","OUTCOMES_CURRENT","PARTNERS_CURRENT","PARTNERS_ROLES"],
            "workforce": ["ORG_PROGRAMS","ORG_PROGRAMS_PLANNED","OUTCOMES_CURRENT","PARTNERS_CURRENT","PARTNERS_ROLES"],
            "housing": ["ORG_PROGRAMS","ORG_PROGRAMS_PLANNED","ORG_CAPACITY","PARTNERS_CURRENT"],
            "reentry": ["ORG_POPULATION_SERVED","ORG_PROGRAMS","ORG_PROGRAMS_PLANNED","ORG_EXPERIENCE","OUTCOMES_CURRENT"],
            "tax-exempt": ["ORG_TAX_EXEMPT_STATUS"],
            "501(c)(3)": ["ORG_TAX_EXEMPT_STATUS"],
            "legal": ["ORG_LEGAL_NAME","ORG_STATE_STATUS","ORG_TAX_EXEMPT_STATUS"],
        }
        for term, mapped in keyword_map.items():
            if term in p:
                ids.extend(mapped)
        return list(dict.fromkeys(ids))
