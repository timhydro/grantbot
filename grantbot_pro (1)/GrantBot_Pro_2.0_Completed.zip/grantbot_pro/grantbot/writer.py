from .analysis import PersuasionEngine

class AIProvider:
    def generate(self, system, prompt, context=None):
        raise NotImplementedError

class MockProvider(AIProvider):
    def generate(self, system, prompt, context=None):
        marker = "\n\nDraft:\n"
        return prompt.split(marker, 1)[-1].strip()

class GrantWriter:
    def __init__(self, provider=None):
        self.provider = provider or MockProvider()
        self.persuasion = PersuasionEngine()

    def draft_section(self, requirement, answer, context, mode="enhanced"):
        enhanced = self.persuasion.enhance(
            answer or "",
            requirement,
            context=context,
            mode=mode,
        )
        system = (
            "Write professional grant language. Improve clarity, specificity, "
            "storytelling, funder alignment and measurable impact. Do not turn "
            "unsupported assumptions into established facts."
        )
        prompt = f"Requirement:\n{requirement}\n\nDraft:\n{enhanced}"
        return self.provider.generate(system, prompt, context)
