"""Owner-confirmed Broken Growth facts and unresolved verification items.

The seed intentionally distinguishes current activity from future plans. It does
not include an EIN, exact legal name, formation date, financial claims, outcome
claims, or partnership commitments because supporting records were not supplied
with this project archive.
"""

BROKEN_GROWTH_FACTS = {
    "ORG_PUBLIC_NAME": {
        "value": "Broken Growth Ministries",
        "source": "organization_owner",
        "provenance": "USER_FACT",
        "verified": True,
    },
    "ORG_STATE_STATUS": {
        "value": "The organization owner reports that Broken Growth Ministries is incorporated in Florida as a nonprofit corporation.",
        "source": "organization_owner",
        "provenance": "USER_FACT",
        "verified": True,
    },
    "ORG_TAX_EXEMPT_STATUS": {
        "value": "Federal recognition under Internal Revenue Code section 501(c)(3) has not yet been confirmed by an IRS determination letter.",
        "source": "organization_owner",
        "provenance": "USER_FACT",
        "verified": True,
    },
    "ORG_MISSION": {
        "value": (
            "Broken Growth Ministries helps adults returning from jail or prison and people experiencing homelessness move toward stability and independence through faith-centered support, housing and employment pathways, mentorship, life-skills development, resource navigation, and supportive community."
        ),
        "source": "organization_owner",
        "provenance": "USER_FACT",
        "verified": True,
    },
    "ORG_VISION": {
        "value": (
            "A community in which people returning from incarceration and people experiencing homelessness have a safe place to live, meaningful work, reliable support, and a genuine opportunity to rebuild their lives."
        ),
        "source": "organization_owner",
        "provenance": "USER_FACT",
        "verified": True,
    },
    "ORG_SERVICE_AREA": {
        "value": "The initial service area is Pensacola and Escambia County, Florida.",
        "source": "organization_owner",
        "provenance": "USER_FACT",
        "verified": True,
    },
    "ORG_POPULATION_SERVED": {
        "value": "Adults age 18 and older who are returning from jail or prison or experiencing homelessness in the Pensacola and Escambia County area.",
        "source": "organization_owner",
        "provenance": "USER_FACT",
        "verified": True,
    },
    "ORG_PROGRAMS": {
        "value": "Current small-scale assistance reported by the organization owner includes food, clothing, resource support, and connections to odd-job opportunities.",
        "source": "organization_owner",
        "provenance": "USER_FACT",
        "verified": True,
    },
    "ORG_PROGRAMS_PLANNED": {
        "value": (
            "Planned services include transitional tiny-home housing, structured reentry intake before release, employment placement, workforce training, mentorship, life-skills education, transportation assistance, and resource navigation. These activities must be described as planned until operational records verify implementation."
        ),
        "source": "organization_owner",
        "provenance": "USER_FACT",
        "verified": True,
    },
    "ORG_LEADERSHIP": {
        "value": "Timothy Oates serves as CEO and President; Gary Tompkins serves as Vice President; Tracy Helton serves as Secretary.",
        "source": "organization_owner",
        "provenance": "USER_FACT",
        "verified": True,
    },
    "ORG_BOARD": {
        "value": "The reported three-member governing board consists of Timothy Oates, Gary Tompkins, and Tracy Helton in their stated officer roles.",
        "source": "organization_owner",
        "provenance": "USER_FACT",
        "verified": True,
    },
    "NEED_PRIMARY_PROBLEM": {
        "value": "The organization addresses instability faced by adults returning from incarceration and adults experiencing homelessness, particularly barriers to safe housing, employment, and coordinated community support.",
        "source": "organization_owner",
        "provenance": "USER_FACT",
        "verified": True,
    },
    "NEED_WHO_AFFECTED": {
        "value": "Adults age 18 and older returning from incarceration or experiencing homelessness in Pensacola and Escambia County are the primary population affected.",
        "source": "organization_owner",
        "provenance": "USER_FACT",
        "verified": True,
    },
}


BROKEN_GROWTH_VERIFICATION_NEEDED = [
    "Exact legal name as shown in the filed Florida articles of incorporation",
    "Employer Identification Number (EIN) from the IRS notice",
    "Florida incorporation filing date and current state record",
    "IRS exemption application status and, when issued, the determination letter",
    "Current organizational mailing and physical addresses",
    "Approved operating budget, financial statements, and bank records",
    "Documented number of people served and measurable outcomes achieved",
    "Signed partnership, referral, and employer commitment agreements",
    "Confirmed job types, position counts, wages, schedules, training, and credentials",
    "Land ownership or site-control documents, zoning approval, and development estimates",
    "Conflict-of-interest, financial-control, participant-safety, and data-privacy policies",
    "Current insurance coverage and required licenses or permits",
]
