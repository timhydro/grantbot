import os
import secrets
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent


def database_uri():
    configured = os.getenv("GRANTBOT_DATABASE_URL")
    if configured:
        if configured.startswith("postgres://"):
            return configured.replace("postgres://", "postgresql+psycopg://", 1)
        if configured.startswith("postgresql://"):
            return configured.replace("postgresql://", "postgresql+psycopg://", 1)
        return configured
    if os.getenv("VERCEL"):
        return "sqlite:////tmp/grantbot.db"
    return f"sqlite:///{BASE_DIR / 'grantbot.db'}"

class Config:
    SECRET_KEY = os.getenv("GRANTBOT_SECRET_KEY") or secrets.token_urlsafe(48)
    SQLALCHEMY_DATABASE_URI = database_uri()
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {"pool_pre_ping": True}
    MAX_CONTENT_LENGTH = int(os.getenv("GRANTBOT_MAX_REQUEST_BYTES", "1048576"))
    REQUIRE_API_KEY = os.getenv(
        "GRANTBOT_REQUIRE_API_KEY",
        "1" if os.getenv("VERCEL") else "0",
    ).lower() in {"1", "true", "yes", "on"}
    API_KEY = os.getenv("GRANTBOT_API_KEY")
    SEED_PROFILE = os.getenv("GRANTBOT_SEED_PROFILE", "1").lower() in {"1", "true", "yes", "on"}
    JSON_SORT_KEYS = False
    MODEL_PATH = os.getenv(
        "GRANTBOT_MODEL_PATH",
        str(BASE_DIR / "models" / "grant_ml.pkl"),
    )
