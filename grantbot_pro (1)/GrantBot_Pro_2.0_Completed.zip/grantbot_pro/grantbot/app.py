import hmac
from functools import wraps

from flask import Flask, jsonify, render_template, request
from werkzeug.exceptions import BadRequest, HTTPException

from .config import Config
from .db import db
from .organization_profile import (
    BROKEN_GROWTH_FACTS,
    BROKEN_GROWTH_VERIFICATION_NEEDED,
)
from .services import GrantBotService


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)
    db.init_app(app)

    with app.app_context():
        db.create_all()
        bot = GrantBotService()
        if app.config["SEED_PROFILE"]:
            bot.kb.seed(BROKEN_GROWTH_FACTS)

    def require_api_key(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not app.config["REQUIRE_API_KEY"]:
                return view(*args, **kwargs)
            configured = app.config.get("API_KEY")
            provided = request.headers.get("X-GrantBot-Key", "")
            if not configured:
                return jsonify({"error": "server_configuration_error", "message": "GRANTBOT_API_KEY is required."}), 503
            if not hmac.compare_digest(provided, configured):
                return jsonify({"error": "unauthorized", "message": "A valid X-GrantBot-Key header is required."}), 401
            return view(*args, **kwargs)
        return wrapped

    def json_body(required=()):
        if not request.is_json:
            raise BadRequest("Request body must use application/json.")
        data = request.get_json(silent=False)
        if not isinstance(data, dict):
            raise BadRequest("Request body must be a JSON object.")
        missing = [key for key in required if key not in data]
        if missing:
            raise BadRequest("Missing required field(s): " + ", ".join(missing))
        return data

    def service():
        return GrantBotService()

    def required_text(data, key):
        value = data.get(key)
        if not isinstance(value, str) or not value.strip():
            raise BadRequest(f"{key} must be a non-empty string.")
        return value.strip()

    def optional_bool(data, key, default=False):
        value = data.get(key, default)
        if not isinstance(value, bool):
            raise BadRequest(f"{key} must be true or false.")
        return value

    def optional_limit(data, key):
        value = data.get(key)
        if value is not None and (isinstance(value, bool) or not isinstance(value, int) or value <= 0):
            raise BadRequest(f"{key} must be a positive integer.")
        return value

    def required_terms(data):
        value = data.get("required_terms")
        if value is not None and (not isinstance(value, list) or not all(isinstance(x, str) for x in value)):
            raise BadRequest("required_terms must be an array of strings.")
        return value

    @app.after_request
    def security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cache-Control"] = "no-store"
        return response

    @app.errorhandler(HTTPException)
    def http_error(error):
        return jsonify({"error": error.name.lower().replace(" ", "_"), "message": error.description}), error.code

    @app.errorhandler(ValueError)
    def value_error(error):
        db.session.rollback()
        return jsonify({"error": "validation_error", "message": str(error)}), 400

    @app.errorhandler(Exception)
    def unhandled_error(error):
        db.session.rollback()
        app.logger.exception("Unhandled GrantBot error")
        return jsonify({"error": "internal_server_error", "message": "The request could not be completed."}), 500

    @app.get("/")
    def index():
        if "text/html" in request.accept_mimetypes:
            return render_template("index.html")
        return jsonify({
            "name": "GrantBot Pro",
            "status": "running",
            "master_profile": service().kb.status(),
        })

    @app.get("/health")
    def health():
        uri = app.config["SQLALCHEMY_DATABASE_URI"]
        return jsonify({
            "status": "ok",
            "database": "postgresql" if uri.startswith("postgresql") else "sqlite",
            "persistent_storage": not uri.startswith("sqlite:////tmp/"),
        })

    @app.get("/api/profile/status")
    @require_api_key
    def profile_status():
        return jsonify(service().kb.status())

    @app.get("/api/profile/missing")
    @require_api_key
    def profile_missing():
        return jsonify(service().kb.missing(
            request.args.get("required_only") == "1",
            request.args.get("verified_only") == "1",
        ))

    @app.get("/api/profile/verification-needed")
    @require_api_key
    def verification_needed():
        return jsonify({
            "organization": "Broken Growth Ministries",
            "items": BROKEN_GROWTH_VERIFICATION_NEEDED,
        })

    @app.get("/api/profile")
    @require_api_key
    def profile():
        return jsonify(service().kb.export())

    @app.post("/api/profile/answer")
    @require_api_key
    def profile_answer():
        data = json_body(("question_id", "value"))
        if not isinstance(data.get("source", "user"), str):
            raise BadRequest("source must be a string.")
        if not isinstance(data.get("provenance", "USER_FACT"), str):
            raise BadRequest("provenance must be a string.")
        bot = service()
        answer = bot.kb.set(
            required_text(data, "question_id"),
            data["value"],
            source=data.get("source", "user"),
            provenance=data.get("provenance", "USER_FACT"),
            verified=optional_bool(data, "verified", False),
            reusable=optional_bool(data, "reusable", True),
        )
        bot.audit("profile_answered", f"Answered {data['question_id']}", "MasterAnswer", answer.id)
        return jsonify({
            "id": answer.id,
            "question_id": answer.question_id,
            "value": answer.value,
            "verified": answer.verified,
            "provenance": answer.provenance,
        }), 201

    @app.post("/api/analyze/requirement")
    @require_api_key
    def analyze_requirement():
        data = json_body(("prompt",))
        if not isinstance(data.get("category", "other"), str):
            raise BadRequest("category must be a string.")
        return jsonify(service().analyze_requirement(required_text(data, "prompt"), data.get("category", "other")))

    @app.post("/api/draft")
    @require_api_key
    def draft():
        data = json_body(("prompt",))
        if not isinstance(data.get("answer", ""), str):
            raise BadRequest("answer must be a string.")
        if not isinstance(data.get("mode", "enhanced"), str):
            raise BadRequest("mode must be a string.")
        return jsonify(service().draft(
            required_text(data, "prompt"),
            data.get("answer", ""),
            data.get("mode", "enhanced"),
            answer_verified=optional_bool(data, "answer_verified", False),
            word_limit=optional_limit(data, "word_limit"),
            character_limit=optional_limit(data, "character_limit"),
            required_terms=required_terms(data),
        ))

    @app.post("/api/compliance")
    @require_api_key
    def compliance():
        data = json_body(("text",))
        if not isinstance(data["text"], str):
            raise BadRequest("text must be a string.")
        return jsonify(service().compliance_check(
            data["text"],
            word_limit=optional_limit(data, "word_limit"),
            character_limit=optional_limit(data, "character_limit"),
            required_terms=required_terms(data),
        ))

    @app.post("/api/budget/reconcile")
    @require_api_key
    def budget_reconcile():
        data = json_body(("items",))
        if not isinstance(data["items"], list):
            raise BadRequest("items must be a JSON array.")
        return jsonify(service().budget_check(data.get("narrative", ""), data["items"]))

    @app.post("/api/readiness")
    @require_api_key
    def readiness():
        data = json_body()
        metrics = data.get("metrics", {})
        if not isinstance(metrics, dict):
            raise BadRequest("metrics must be a JSON object.")
        return jsonify(service().readiness(data.get("text", ""), metrics))

    return app


if __name__ == "__main__":
    create_app().run(host="127.0.0.1", port=5000, debug=False)
