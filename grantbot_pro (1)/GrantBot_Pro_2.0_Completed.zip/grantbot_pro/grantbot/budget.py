class BudgetEngine:
    def total(self, items):
        total = 0.0
        for index, item in enumerate(items):
            try:
                amount = float(item.get("amount", 0) or 0)
            except (TypeError, ValueError) as exc:
                raise ValueError(f"Budget item {index + 1} has an invalid amount.") from exc
            if amount < 0:
                raise ValueError(f"Budget item {index + 1} cannot have a negative amount.")
            total += amount
        return round(total, 2)

    def reconcile(self, narrative, items):
        total = self.total(items)
        normalized_total = f"{total:,.2f}"
        text = (narrative or "").replace("$", "").replace(",", "")
        contains_total = any(token in text for token in {str(total), f"{total:.2f}", str(int(total)) if total.is_integer() else ""})
        issues = []
        if not items:
            issues.append("No budget line items were supplied.")
        if items and not contains_total:
            issues.append(f"Narrative does not state the reconciled budget total of ${normalized_total}.")
        return {
            "budget_total": total,
            "line_items": len(items),
            "narrative_contains_total": contains_total,
            "issues": issues,
        }
