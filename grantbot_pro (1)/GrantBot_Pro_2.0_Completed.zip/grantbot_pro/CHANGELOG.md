# Changelog

## 2.0.0 — 2026-08-13

- added verified-fact-only drafting and fact provenance
- added Broken Growth Ministries profile seed and verification checklist
- added missing/unverified submission gates
- added API validation, authentication option, security headers, and safe errors
- exposed budget and compliance checks
- protected ML model loading with checksums
- added browser dashboard and Vercel deployment support
- expanded automated coverage from 2 to 26 tests
