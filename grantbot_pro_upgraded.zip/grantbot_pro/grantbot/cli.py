import argparse
from .app import create_app
from .db import db
from .services import GrantBotService

def main():
    parser = argparse.ArgumentParser(prog="grantbot")
    sub = parser.add_subparsers(dest="cmd")
    sub.add_parser("init")
    sub.add_parser("status")
    ans = sub.add_parser("answer")
    ans.add_argument("question_id")
    ans.add_argument("value")
    sub.add_parser("missing")
    args = parser.parse_args()

    app = create_app()
    with app.app_context():
        service = GrantBotService()
        if args.cmd == "init":
            db.create_all()
            print("GrantBot Pro database initialized.")
        elif args.cmd == "status":
            print(service.kb.status())
        elif args.cmd == "missing":
            for q in service.kb.missing():
                print(f"{q['id']}: {q['question']}")
        elif args.cmd == "answer":
            service.kb.set(args.question_id, args.value)
            print(f"Saved {args.question_id}.")
        else:
            parser.print_help()

if __name__ == "__main__":
    main()
