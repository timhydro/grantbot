import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent

class Config:
    SECRET_KEY = os.getenv("GRANTBOT_SECRET_KEY", "dev-only-change-me")
    SQLALCHEMY_DATABASE_URI = os.getenv(
        "GRANTBOT_DATABASE_URL",
        f"sqlite:///{BASE_DIR / 'grantbot.db'}",
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    MODEL_PATH = os.getenv(
        "GRANTBOT_MODEL_PATH",
        str(BASE_DIR / "models" / "grant_ml.pkl"),
    )
