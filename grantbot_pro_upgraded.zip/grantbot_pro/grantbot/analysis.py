import re

class AnswerSufficiencyEngine:
    """Scores completeness without pretending that a score is factual truth."""

    def score(self, answer, expected_terms=None):
        answer = (answer or "").strip()
        words = len(answer.split())
        specificity = min(1.0, words / 120.0)
        structure = 1.0 if any(x in answer for x in [".", ";", "\n"]) else 0.4
        evidence = 1.0 if re.search(r"\d|according to|report|study|data|survey", answer, re.I) else 0.25
        relevance = 1.0
        if expected_terms:
            hits = sum(1 for term in expected_terms if term.lower() in answer.lower())
            relevance = hits / max(1, len(expected_terms))
        score = round((specificity*.30 + structure*.15 + evidence*.25 + relevance*.30) * 100, 1)
        gaps = []
        if words < 25: gaps.append("more specificity")
        if evidence < .5: gaps.append("supporting evidence or clearly labeled context")
        if expected_terms and relevance < .6: gaps.append("direct coverage of required concepts")
        return {"score": score, "gaps": gaps, "word_count": words}

class PersuasionEngine:
    """
    Produces an enhancement brief rather than silently fabricating facts.
    Supports factual, enhanced, and creative-draft workflows.
    """

    def build_brief(self, answer, requirement, mode="enhanced"):
        analysis = AnswerSufficiencyEngine().score(answer)
        return {
            "mode": mode,
            "original": answer,
            "requirement": requirement,
            "recommended_structure": [
                "lead with the problem or human significance",
                "connect the problem to the proposed response",
                "use concrete details and measurable outcomes where available",
                "show organizational credibility",
                "close with funder-aligned impact",
            ],
            "gaps": analysis["gaps"],
            "provenance_policy": "label material assumptions/placeholders for review",
        }

    def enhance(self, answer, requirement, context=None, mode="enhanced"):
        brief = self.build_brief(answer, requirement, mode)
        context = context or {}
        if mode == "factual":
            return answer.strip()
        # Deterministic local fallback. Production LLM providers can replace this.
        lead = answer.strip()
        additions = []
        if context.get("ORG_MISSION"):
            additions.append(f"The work is closely connected to the organization's mission: {context['ORG_MISSION']}")
        if context.get("NEED_EVIDENCE"):
            additions.append(f"Available supporting evidence includes: {context['NEED_EVIDENCE']}")
        if context.get("OUTCOMES_CURRENT"):
            additions.append(f"Relevant demonstrated outcomes include: {context['OUTCOMES_CURRENT']}")
        if mode == "creative_draft":
            additions.append("[Add a specific human-centered example or story here.]")
        return "\n\n".join([lead] + additions)

class RequirementMapper:
    def map(self, prompt, category="other"):
        p = prompt.lower()
        ids = []
        from .questions import QUESTION_MAP
        if category in QUESTION_MAP:
            ids.extend(QUESTION_MAP[category])
        keyword_map = {
            "mission": ["ORG_MISSION"],
            "history": ["ORG_HISTORY"],
            "organization": ["ORG_MISSION","ORG_HISTORY","ORG_PROGRAMS","ORG_ACCOMPLISHMENTS"],
            "need": ["NEED_PRIMARY_PROBLEM","NEED_WHO_AFFECTED","NEED_SCOPE","NEED_EVIDENCE"],
            "outcome": ["OUTCOMES_CURRENT","EVALUATION_METHOD"],
            "evaluation": ["EVALUATION_METHOD","EVALUATION_DATA"],
            "sustain": ["SUSTAINABILITY","SUSTAINABILITY_REVENUE"],
            "partner": ["PARTNERS_CURRENT","PARTNERS_ROLES"],
            "budget": ["FIN_ANNUAL_BUDGET","FIN_EXPENSES","FIN_REVENUE"],
        }
        for term, mapped in keyword_map.items():
            if term in p:
                ids.extend(mapped)
        return list(dict.fromkeys(ids))
