from flask import Flask, jsonify, request
from .config import Config
from .db import db
from .services import GrantBotService
from .models import Requirement, GrantOpportunity

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    db.init_app(app)

    with app.app_context():
        db.create_all()

    service = GrantBotService()

    @app.get("/")
    def index():
        return jsonify({
            "name": "GrantBot Pro",
            "status": "running",
            "master_profile": service.kb.status(),
        })

    @app.get("/api/profile/status")
    def profile_status():
        return jsonify(service.kb.status())

    @app.get("/api/profile/missing")
    def profile_missing():
        return jsonify(service.kb.missing(request.args.get("required_only") == "1"))

    @app.get("/api/profile")
    def profile():
        return jsonify(service.kb.export())

    @app.post("/api/profile/answer")
    def profile_answer():
        data = request.get_json(force=True)
        answer = service.kb.set(
            data["question_id"],
            data["value"],
            source=data.get("source", "user"),
            provenance=data.get("provenance", "USER_FACT"),
            verified=bool(data.get("verified", True)),
            reusable=bool(data.get("reusable", True)),
        )
        service.audit("profile_answered", f"Answered {data['question_id']}", "MasterAnswer", answer.id)
        return jsonify({"id": answer.id, "question_id": answer.question_id, "value": answer.value})

    @app.post("/api/analyze/requirement")
    def analyze_requirement():
        data = request.get_json(force=True)
        return jsonify(service.analyze_requirement(data["prompt"], data.get("category", "other")))

    @app.post("/api/draft")
    def draft():
        data = request.get_json(force=True)
        return jsonify(service.draft(
            data["prompt"],
            data.get("answer", ""),
            data.get("mode", "enhanced"),
        ))

    @app.post("/api/readiness")
    def readiness():
        data = request.get_json(force=True)
        return jsonify(service.readiness(data.get("text", ""), data.get("metrics", {})))

    return app

if __name__ == "__main__":
    create_app().run(host="127.0.0.1", port=5000, debug=True)
