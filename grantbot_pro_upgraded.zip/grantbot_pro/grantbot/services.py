import json
from .db import db
from .models import AuditEvent, Requirement, Proposal, GrantOpportunity, Project
from .knowledge import KnowledgeBase
from .analysis import RequirementMapper, AnswerSufficiencyEngine
from .writer import GrantWriter
from .compliance import ComplianceEngine, ConsistencyEngine
from .budget import BudgetEngine
from .ml import GrantMLEngine

class GrantBotService:
    def __init__(self):
        self.kb = KnowledgeBase()
        self.mapper = RequirementMapper()
        self.sufficiency = AnswerSufficiencyEngine()
        self.writer = GrantWriter()
        self.compliance = ComplianceEngine()
        self.consistency = ConsistencyEngine()
        self.budget = BudgetEngine()
        self.ml = GrantMLEngine()

    def audit(self, event_type, message, entity_type=None, entity_id=None, data=None):
        db.session.add(AuditEvent(
            event_type=event_type,
            entity_type=entity_type,
            entity_id=str(entity_id) if entity_id is not None else None,
            message=message,
            data_json=json.dumps(data or {}, default=str),
        ))
        db.session.commit()

    def analyze_requirement(self, prompt, category="other"):
        mapped = self.mapper.map(prompt, category)
        missing = [qid for qid in mapped if self.kb.get(qid) is None]
        return {"mapped_question_ids": mapped, "missing_question_ids": missing}

    def draft(self, prompt, answer, mode="enhanced"):
        context = self.kb.context()
        result = self.writer.draft_section(prompt, answer, context, mode)
        compliance = self.compliance.check(result)
        return {"draft": result, "compliance": compliance}

    def readiness(self, text, requirement_metrics=None):
        metrics = requirement_metrics or {}
        features = self.ml.extract_features(text, metrics=metrics)
        score = self.ml.predict(text, metrics=metrics)
        return {"prediction": score, "features": features, "feature_importance": self.ml.feature_importance()}
