class BudgetEngine:
    def total(self, items):
        return round(sum(float(x.get("amount", 0) or 0) for x in items), 2)

    def reconcile(self, narrative, items):
        total = self.total(items)
        return {
            "budget_total": total,
            "line_items": len(items),
            "narrative_contains_total": str(total) in (narrative or ""),
            "issues": [],
        }
