import json
from datetime import datetime
from .db import db
from .models import MasterAnswer
from .questions import MASTER_QUESTIONS

class KnowledgeBase:
    def __init__(self):
        self.questions = {
            q[0]: {
                "id": q[0], "category": q[1], "question": q[2],
                "type": q[3], "required": q[4], "reusable": True
            } for q in MASTER_QUESTIONS
        }

    def get(self, question_id):
        answer = (MasterAnswer.query
                  .filter_by(question_id=question_id, valid_to=None)
                  .order_by(MasterAnswer.updated_at.desc())
                  .first())
        return answer.value if answer else None

    def set(self, question_id, value, source="user",
            provenance="USER_FACT", verified=True, reusable=True):
        if question_id not in self.questions:
            raise ValueError(f"Unknown question ID: {question_id}")
        old = (MasterAnswer.query
               .filter_by(question_id=question_id, valid_to=None)
               .order_by(MasterAnswer.updated_at.desc())
               .first())
        if old:
            old.valid_to = datetime.utcnow()
        answer = MasterAnswer(
            question_id=question_id,
            value=str(value).strip(),
            answer_type=self.questions[question_id]["type"],
            source=source,
            provenance=provenance,
            verified=verified,
            reusable=reusable,
            last_verified=datetime.utcnow() if verified else None,
        )
        db.session.add(answer)
        db.session.commit()
        return answer

    def missing(self, required_only=False):
        result = []
        for q in self.questions.values():
            if required_only and not q["required"]:
                continue
            if self.get(q["id"]) is None:
                result.append(q)
        return result

    def status(self):
        total = len(self.questions)
        answered = total - len(self.missing())
        required = len([q for q in self.questions.values() if q["required"]])
        required_missing = len(self.missing(True))
        return {
            "total": total,
            "answered": answered,
            "remaining": total - answered,
            "completion_percent": round(answered / total * 100, 1) if total else 100,
            "required": required,
            "required_remaining": required_missing,
            "required_completion_percent":
                round((required - required_missing) / required * 100, 1) if required else 100,
        }

    def context(self, question_ids=None):
        ids = question_ids or list(self.questions)
        return {
            qid: self.get(qid)
            for qid in ids
            if self.get(qid) is not None
        }

    def export(self):
        return {
            qid: {"question": q["question"], "answer": self.get(qid)}
            for qid, q in self.questions.items()
        }
