from datetime import datetime
from .db import db

class TimestampMixin:
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(
        db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

class MasterAnswer(TimestampMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    question_id = db.Column(db.String(160), nullable=False, index=True)
    value = db.Column(db.Text, nullable=False)
    answer_type = db.Column(db.String(50), default="text", nullable=False)
    source = db.Column(db.String(50), default="user", nullable=False)
    provenance = db.Column(db.String(50), default="USER_FACT", nullable=False)
    reusable = db.Column(db.Boolean, default=True, nullable=False)
    verified = db.Column(db.Boolean, default=False, nullable=False)
    valid_from = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    valid_to = db.Column(db.DateTime, nullable=True)
    last_verified = db.Column(db.DateTime, nullable=True)

class Evidence(TimestampMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(300), nullable=False)
    evidence_type = db.Column(db.String(80), nullable=False, default="other")
    description = db.Column(db.Text, nullable=False)
    source = db.Column(db.String(500), nullable=True)
    citation = db.Column(db.Text, nullable=True)
    publication_date = db.Column(db.DateTime, nullable=True)
    verified = db.Column(db.Boolean, default=False, nullable=False)
    review_date = db.Column(db.DateTime, nullable=True)
    tags = db.Column(db.Text, nullable=True)

class Project(TimestampMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(300), nullable=False)
    description = db.Column(db.Text, nullable=True)
    data_json = db.Column(db.Text, nullable=False, default="{}")

class Funder(TimestampMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(300), nullable=False, unique=True)
    data_json = db.Column(db.Text, nullable=False, default="{}")

class GrantOpportunity(TimestampMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    funder_id = db.Column(db.Integer, db.ForeignKey("funder.id"), nullable=True)
    name = db.Column(db.String(300), nullable=False)
    deadline = db.Column(db.DateTime, nullable=True)
    data_json = db.Column(db.Text, nullable=False, default="{}")

class Requirement(TimestampMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    grant_id = db.Column(db.Integer, db.ForeignKey("grant_opportunity.id"), nullable=False)
    external_id = db.Column(db.String(160), nullable=True)
    prompt = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(100), nullable=False, default="other")
    required = db.Column(db.Boolean, default=True, nullable=False)
    word_limit = db.Column(db.Integer, nullable=True)
    character_limit = db.Column(db.Integer, nullable=True)
    weight = db.Column(db.Float, default=1.0, nullable=False)
    mapped_question_ids_json = db.Column(db.Text, nullable=False, default="[]")

class Proposal(TimestampMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    grant_id = db.Column(db.Integer, db.ForeignKey("grant_opportunity.id"), nullable=False)
    project_id = db.Column(db.Integer, db.ForeignKey("project.id"), nullable=True)
    version = db.Column(db.Integer, default=1, nullable=False)
    status = db.Column(db.String(50), default="draft", nullable=False)
    mode = db.Column(db.String(50), default="enhanced", nullable=False)
    sections_json = db.Column(db.Text, nullable=False, default="{}")
    scores_json = db.Column(db.Text, nullable=False, default="{}")

class Outcome(TimestampMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    proposal_id = db.Column(db.Integer, db.ForeignKey("proposal.id"), nullable=False)
    outcome = db.Column(db.Float, nullable=False)
    reviewer_feedback = db.Column(db.Text, nullable=True)
    award_amount = db.Column(db.Float, nullable=True)
    submitted_at = db.Column(db.DateTime, nullable=True)

class AuditEvent(TimestampMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    event_type = db.Column(db.String(120), nullable=False)
    entity_type = db.Column(db.String(120), nullable=True)
    entity_id = db.Column(db.String(120), nullable=True)
    message = db.Column(db.Text, nullable=False)
    data_json = db.Column(db.Text, nullable=False, default="{}")
