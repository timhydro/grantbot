import re

class ComplianceEngine:
    def check(self, text, word_limit=None, character_limit=None, required_terms=None):
        words = len(text.split())
        chars = len(text)
        issues = []
        if word_limit and words > word_limit:
            issues.append(f"Word limit exceeded by {words-word_limit} words.")
        if character_limit and chars > character_limit:
            issues.append(f"Character limit exceeded by {chars-character_limit} characters.")
        missing = []
        for term in required_terms or []:
            if term.lower() not in text.lower():
                missing.append(term)
        if missing:
            issues.append("Missing required concepts: " + ", ".join(missing))
        return {
            "passed": not issues,
            "word_count": words,
            "character_count": chars,
            "issues": issues,
            "missing_terms": missing,
        }

class ConsistencyEngine:
    def compare(self, sections):
        numbers = {}
        conflicts = []
        for name, text in sections.items():
            for token in re.findall(r"(?<!\w)\d+(?:\.\d+)?(?:\s*[%$])?", text or ""):
                numbers.setdefault(token, []).append(name)
        # Flag repeated numeric values only as a review aid; semantic contradiction
        # requires a stronger document/NLP layer.
        return {"numeric_mentions": numbers, "conflicts": conflicts}
