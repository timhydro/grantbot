import os
import tempfile
import pytest

from grantbot.app import create_app

@pytest.fixture()
def app():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    app = create_app()
    app.config.update(
        TESTING=True,
        SQLALCHEMY_DATABASE_URI=f"sqlite:///{path}",
    )
    from grantbot.db import db
    with app.app_context():
        db.drop_all()
        db.create_all()
    yield app
    os.unlink(path)

def test_status(app):
    client = app.test_client()
    response = client.get("/api/profile/status")
    assert response.status_code == 200
    assert "completion_percent" in response.json

def test_answer_round_trip(app):
    client = app.test_client()
    response = client.post("/api/profile/answer", json={
        "question_id": "ORG_MISSION",
        "value": "We strengthen communities through housing and opportunity.",
    })
    assert response.status_code == 200
    response = client.get("/api/profile")
    assert response.status_code == 200
    assert response.json["ORG_MISSION"]["answer"]
