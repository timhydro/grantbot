# GrantBot Pro

A modular grant-application intelligence platform.

Core capabilities:
- reusable master organization knowledge base
- versioned answers and provenance
- project profiles
- evidence library
- grant/funder profiles
- requirement mapping
- dynamic missing-information interview
- answer sufficiency scoring
- persuasive/enhanced drafting modes
- rubric/compliance/consistency checks
- budget/narrative alignment checks
- historical outcome ML
- Flask web UI and CLI
- audit trail

## Quick start

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -m grantbot.cli init
python -m grantbot.cli status
python -m grantbot.app
```

The default AI provider is `mock`, which creates deterministic drafts without requiring an API key.
Add a provider implementation under `grantbot/ai/providers/` for a production LLM.

## Important design principle

GrantBot can strengthen incomplete answers, infer structure, improve storytelling, and produce persuasive grant language. It should distinguish user facts, document facts, calculations, inferences, creative language, and placeholders so a human can review material claims before submission.
