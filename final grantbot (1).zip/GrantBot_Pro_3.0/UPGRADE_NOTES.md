# GrantBot Pro 3.0 Upgrade Notes

## Completed in this release

- Rebuilt focused grant writer; irrelevant profile facts are no longer dumped into every response.
- Added fact provenance, verified/usable state, version history, and missing-information blocking.
- Expanded the Broken Growth knowledge interview to 121 questions.
- Added founder-stated Broken Growth seed facts while leaving unresolved legal, financial, operational, outcome, wage, partnership, and capacity facts unanswered.
- Added official Grants.gov search2 and fetchOpportunity clients.
- Added eligibility hard gates for closed/archived grants and clearly incompatible academic, Tribal, government-only, small-business-only, and fellowship opportunities.
- Added weighted matching for reentry, homelessness, housing, employment, workforce development, and supportive services.
- Added deadline urgency, warnings, priority, and recommended action.
- Added NOFO extraction for PDF, DOCX, TXT, and Markdown plus requirement/limit detection.
- Added grant-specific missing-question analysis.
- Added verified evidence library and relevance selection for need/outcome/capacity narratives.
- Added numeric, placeholder, and unsupported-absolute claim checks.
- Added budget calculation/reconciliation and cross-section consistency checks.
- Added saved grants, projects, requirements, proposals, section drafting/review, and recorded outcomes.
- Completed historical readiness engine with deterministic scoring before sufficient real outcomes exist and trained Random Forest scoring after enough real outcome samples are recorded.
- Added optional local Ollama generation with automatic fact-safe fallback.
- Added `python -m grantbot serve`.
- Added local browser dashboard at http://127.0.0.1:5000.
- Made bootstrap idempotent and configured it to compile and run the full pytest suite during installation.

## Verification performed in build workspace

- Python compileall: PASS
- 121-question schema check: PASS
- high-fit reentry/workforce/housing match: PASS (80/100 test case)
- academic eligibility hard rejection: PASS
- unsupported numeric claim detection: PASS
- NOFO requirement/word-limit extraction: PASS
- budget math/reconciliation core logic: PASS

The build workspace could not download third-party Python packages because outbound package-index access was unavailable, so the Flask/SQLAlchemy pytest suite is configured to run automatically on the target machine during `bootstrap.sh`. Installation stops immediately if that suite fails.
