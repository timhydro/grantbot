#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v python3 >/dev/null || { echo "ERROR: python3 is required." >&2; exit 1; }
if [ ! -d .venv ]; then python3 -m venv .venv; fi
. .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
python -m compileall -q grantbot
python -m grantbot init >/dev/null
python -m pytest -q
echo "=== GRANTBOT PRO 3.0 INSTALL COMPLETE ==="
echo "Start: cd $(pwd) && .venv/bin/python -m grantbot serve"
echo "Questions: .venv/bin/python -m grantbot questions"
echo "Missing facts: .venv/bin/python -m grantbot missing --required"
