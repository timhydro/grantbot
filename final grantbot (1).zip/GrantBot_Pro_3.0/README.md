# GrantBot Pro 3.0 — Broken Growth Ministries

Production-oriented local grant intelligence and writing system. The core works without a paid AI API. Optional Ollama support adds local LLM drafting while the fact and claim-safety layers remain authoritative.

## Complete pipeline

`Grants.gov search -> opportunity detail -> eligibility gate -> mission-fit score -> deadline priority -> NOFO requirements -> missing fact questions -> verified-fact draft -> claim check -> compliance/budget/consistency review`

## Core capabilities

- 100+ question master organizational knowledge interview
- versioned fact bank with provenance and verification state
- Broken Growth founder-stated seed facts, with unknown facts intentionally left missing
- official Grants.gov `search2` and `fetchOpportunity` integration
- hard eligibility gates for specialized academic, Tribal, government-only, closed, and incompatible opportunities
- weighted mission-fit scoring for reentry, homelessness, housing, employment, workforce, and supportive services
- deadline urgency and grant priority scoring
- PDF/DOCX/TXT/Markdown NOFO text extraction and requirement detection
- requirement-to-fact mapping and grant-specific missing-question generation
- focused grant writer that uses only relevant authorized facts
- optional local Ollama writer (`GRANTBOT_AI_PROVIDER=ollama`)
- numeric/placeholder/absolute-claim safety checker
- word/character compliance checks
- budget math, category totals, request reconciliation, and narrative alignment
- cross-section consistency checks
- historical outcome ML scaffold that only predicts after real training outcomes exist
- Flask API and complete CLI
- audit trail and automated tests

## Install

```bash
bash bootstrap.sh
```

## Start

```bash
.venv/bin/python -m grantbot serve
```

Open `http://127.0.0.1:5000`.

## Essential commands

```bash
.venv/bin/python -m grantbot status
.venv/bin/python -m grantbot questions
.venv/bin/python -m grantbot missing --required
.venv/bin/python -m grantbot answer ORG_MISSION "Your exact approved mission"
.venv/bin/python -m grantbot analyze "Describe your employment and job training program"
.venv/bin/python -m grantbot write "Describe your employment and job training program"
.venv/bin/python -m grantbot search "reentry workforce" --rows 20
.venv/bin/python -m grantbot discover "reentry workforce" --rows 20
.venv/bin/python -m grantbot nofo /path/to/NOFO.pdf
```

## Optional local AI with Ollama

Set in `.env`:

```text
GRANTBOT_AI_PROVIDER=ollama
GRANTBOT_OLLAMA_MODEL=qwen3:8b
```

If Ollama is unavailable, GrantBot automatically falls back to its deterministic fact-safe writer rather than failing or inventing content.

## Fact safety

GrantBot treats missing information as a question, not an invitation to guess. Founder-stated or verified facts can be used; drafts and unknowns cannot silently become grant claims. Always review the final application against the official NOFO and submission portal before filing.
