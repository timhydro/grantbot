from flask import Flask, jsonify, request, render_template
from .config import Config
from .db import db
from .services import GrantBotService


def create_app(config_overrides=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if config_overrides:
        app.config.update(config_overrides)
    db.init_app(app)
    with app.app_context(): db.create_all()

    def service(): return GrantBotService()

    @app.get("/")
    def index(): return render_template("index.html")

    @app.get("/api/health")
    def health():
        s = service(); return jsonify({"name":"GrantBot Pro","version":"3.0.0","status":"running","master_profile":s.kb.status()})

    @app.get("/api/profile/status")
    def profile_status(): return jsonify(service().kb.status())

    @app.get("/api/profile/questions")
    def profile_questions(): return jsonify(list(service().kb.questions.values()))

    @app.get("/api/profile/missing")
    def profile_missing(): return jsonify(service().kb.missing(request.args.get("required_only") == "1", usable_only=True))

    @app.get("/api/profile")
    def profile(): return jsonify(service().kb.export())

    @app.post("/api/profile/seed")
    def profile_seed(): return jsonify(service().seed(bool((request.get_json(silent=True) or {}).get("overwrite", False))))

    @app.post("/api/profile/answer")
    def profile_answer():
        data = request.get_json(force=True); s = service()
        try:
            answer = s.kb.set(data["question_id"], data["value"], source=data.get("source","user"), provenance=data.get("provenance","USER_FACT"), verified=bool(data.get("verified",True)), reusable=bool(data.get("reusable",True)))
        except (KeyError, ValueError) as exc:
            return jsonify({"error": str(exc)}), 400
        s.audit("profile_answered", f"Answered {data['question_id']}", "MasterAnswer", answer.id)
        return jsonify({"id":answer.id,"question_id":answer.question_id,"value":answer.value,"verified":answer.verified})

    @app.post("/api/analyze/requirement")
    def analyze_requirement():
        data=request.get_json(force=True); return jsonify(service().analyze_requirement(data["prompt"], data.get("category","other")))

    @app.post("/api/draft")
    def draft():
        data=request.get_json(force=True); return jsonify(service().draft(data["prompt"], data.get("answer",""), data.get("category","other"), data.get("mode","enhanced"), data.get("word_limit")))

    @app.post("/api/claim-check")
    def claim_check():
        data=request.get_json(force=True); return jsonify(service().claim_checker.check(data.get("text",""), data.get("facts",[])))

    @app.post("/api/grants/search")
    def grants_search():
        data=request.get_json(force=True)
        try: return jsonify(service().discovery.search(data.get("keyword",""), rows=data.get("rows",25)))
        except Exception as exc: return jsonify({"error":str(exc)}), 502

    @app.post("/api/grants/fetch")
    def grants_fetch():
        data=request.get_json(force=True)
        try: return jsonify(service().discovery.fetch(data["opportunity_id"]))
        except Exception as exc: return jsonify({"error":str(exc)}), 502

    @app.post("/api/grants/match")
    def grants_match(): return jsonify(service().match(request.get_json(force=True)))

    @app.post("/api/grants/discover-match")
    def discover_match():
        data=request.get_json(force=True)
        try: return jsonify(service().discover_and_match(data.get("keyword",""), rows=data.get("rows",25)))
        except Exception as exc: return jsonify({"error":str(exc)}), 502

    @app.post("/api/nofo/analyze")
    def nofo_analyze():
        data=request.get_json(force=True)
        if data.get("text") is not None: return jsonify(service().nofo.analyze(data["text"]))
        try:
            result=service().nofo.parse_file(data["path"]); result.pop("text",None); return jsonify(result)
        except Exception as exc: return jsonify({"error":str(exc)}), 400

    @app.post("/api/budget/reconcile")
    def budget_reconcile():
        data=request.get_json(force=True); return jsonify(service().budget.reconcile(data.get("narrative",""), data.get("items",[]), data.get("requested_amount"), data.get("match_required")))

    @app.post("/api/consistency")
    def consistency(): return jsonify(service().consistency.compare((request.get_json(force=True) or {}).get("sections",{})))

    @app.post("/api/projects")
    def create_project():
        data=request.get_json(force=True)
        try: return jsonify(service().workspace.create_project(data["name"], data.get("description",""), data.get("data",{})))
        except (KeyError, ValueError) as exc: return jsonify({"error":str(exc)}),400

    @app.get("/api/projects")
    def list_projects(): return jsonify(service().workspace.list_projects())

    @app.post("/api/evidence")
    def add_evidence():
        data=request.get_json(force=True)
        try: return jsonify(service().workspace.add_evidence(data["title"], data["description"], data.get("evidence_type","other"), data.get("source"), data.get("citation"), data.get("verified",False), data.get("tags")))
        except (KeyError, ValueError) as exc: return jsonify({"error":str(exc)}),400

    @app.get("/api/evidence")
    def list_evidence(): return jsonify(service().workspace.list_evidence(request.args.get("verified_only")=="1"))

    @app.post("/api/grants/save")
    def save_grant(): return jsonify(service().workspace.save_grant(request.get_json(force=True)))

    @app.get("/api/grants/saved")
    def saved_grants(): return jsonify(service().workspace.list_grants())

    @app.post("/api/grants/<int:grant_id>/requirements")
    def import_requirements(grant_id):
        data=request.get_json(force=True)
        try: return jsonify(service().workspace.import_nofo_requirements(grant_id, text=data.get("text"), path=data.get("path")))
        except Exception as exc: return jsonify({"error":str(exc)}),400

    @app.get("/api/grants/<int:grant_id>/requirements")
    def list_requirements(grant_id): return jsonify(service().workspace.list_requirements(grant_id))

    @app.post("/api/proposals")
    def create_proposal():
        data=request.get_json(force=True)
        try: return jsonify(service().workspace.create_proposal(data["grant_id"], data.get("project_id"), data.get("mode","enhanced")))
        except (KeyError, ValueError) as exc: return jsonify({"error":str(exc)}),400

    @app.post("/api/proposals/<int:proposal_id>/draft")
    def draft_proposal(proposal_id):
        try: return jsonify(service().workspace.draft_proposal(proposal_id))
        except ValueError as exc: return jsonify({"error":str(exc)}),400

    @app.post("/api/proposals/<int:proposal_id>/sections/<int:requirement_id>")
    def set_proposal_section(proposal_id, requirement_id):
        try: return jsonify(service().workspace.set_section(proposal_id, requirement_id, (request.get_json(force=True) or {}).get("text","")))
        except ValueError as exc: return jsonify({"error":str(exc)}),400

    @app.get("/api/proposals/<int:proposal_id>/review")
    def review_proposal(proposal_id):
        try: return jsonify(service().workspace.review_proposal(proposal_id))
        except ValueError as exc: return jsonify({"error":str(exc)}),404

    @app.post("/api/proposals/<int:proposal_id>/outcome")
    def proposal_outcome(proposal_id):
        data=request.get_json(force=True)
        try: return jsonify(service().workspace.record_outcome(proposal_id, data["outcome"], data.get("reviewer_feedback"), data.get("award_amount")))
        except (KeyError, ValueError) as exc: return jsonify({"error":str(exc)}),400

    @app.post("/api/readiness")
    def readiness():
        data=request.get_json(force=True); return jsonify(service().readiness(data.get("text",""), data.get("metrics",{})))

    return app

if __name__ == "__main__":
    create_app().run(host="127.0.0.1", port=5000, debug=False)
