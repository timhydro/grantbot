import argparse
import json
from pathlib import Path
from .app import create_app
from .db import db
from .services import GrantBotService


def dump(obj):
    print(json.dumps(obj, indent=2, default=str))


def main(argv=None):
    parser = argparse.ArgumentParser(prog="grantbot", description="GrantBot Pro 3.0")
    sub = parser.add_subparsers(dest="cmd")
    sub.add_parser("init")
    sub.add_parser("status")
    sub.add_parser("seed")
    sub.add_parser("questions")
    missing = sub.add_parser("missing"); missing.add_argument("--required", action="store_true")
    ans = sub.add_parser("answer"); ans.add_argument("question_id"); ans.add_argument("value"); ans.add_argument("--unverified", action="store_true")
    analyze = sub.add_parser("analyze"); analyze.add_argument("prompt")
    write = sub.add_parser("write"); write.add_argument("prompt"); write.add_argument("--answer", default=""); write.add_argument("--word-limit", type=int)
    search = sub.add_parser("search"); search.add_argument("keyword"); search.add_argument("--rows", type=int, default=20)
    match = sub.add_parser("match"); match.add_argument("json_file")
    discover = sub.add_parser("discover"); discover.add_argument("keyword"); discover.add_argument("--rows", type=int, default=20)
    nofo = sub.add_parser("nofo"); nofo.add_argument("path")
    project = sub.add_parser("project-create"); project.add_argument("name"); project.add_argument("--description", default="")
    evidence = sub.add_parser("evidence-add"); evidence.add_argument("title"); evidence.add_argument("description"); evidence.add_argument("--source"); evidence.add_argument("--verified", action="store_true")
    save_grant = sub.add_parser("grant-save"); save_grant.add_argument("json_file")
    reqs = sub.add_parser("requirements-import"); reqs.add_argument("grant_id", type=int); reqs.add_argument("path")
    proposal = sub.add_parser("proposal-create"); proposal.add_argument("grant_id", type=int); proposal.add_argument("--project-id", type=int)
    pdraft = sub.add_parser("proposal-draft"); pdraft.add_argument("proposal_id", type=int)
    preview = sub.add_parser("proposal-review"); preview.add_argument("proposal_id", type=int)
    outcome = sub.add_parser("proposal-outcome"); outcome.add_argument("proposal_id", type=int); outcome.add_argument("outcome", type=float); outcome.add_argument("--award-amount", type=float)
    serve = sub.add_parser("serve"); serve.add_argument("--host", default="127.0.0.1"); serve.add_argument("--port", type=int, default=5000); serve.add_argument("--debug", action="store_true")
    args = parser.parse_args(argv)

    app = create_app()
    if args.cmd == "serve":
        app.run(host=args.host, port=args.port, debug=args.debug)
        return 0
    with app.app_context():
        service = GrantBotService()
        if args.cmd == "init":
            db.create_all(); result = service.seed(False); dump({"message": "GrantBot Pro database initialized.", **result})
        elif args.cmd == "status": dump(service.kb.status())
        elif args.cmd == "seed": dump(service.seed(False))
        elif args.cmd == "questions":
            for q in service.kb.questions.values(): print(f"{q['id']} | {q['category']} | {'REQUIRED' if q['required'] else 'optional'} | {q['question']}")
        elif args.cmd == "missing":
            for q in service.kb.missing(args.required, usable_only=True): print(f"{q['id']}: {q['question']}")
        elif args.cmd == "answer":
            r = service.kb.set(args.question_id, args.value, verified=not args.unverified, provenance="USER_FACT" if not args.unverified else "DRAFT"); dump({"saved": r.question_id, "verified": r.verified})
        elif args.cmd == "analyze": dump(service.analyze_requirement(args.prompt))
        elif args.cmd == "write": dump(service.draft(args.prompt, args.answer, word_limit=args.word_limit))
        elif args.cmd == "search": dump(service.discovery.search(args.keyword, rows=args.rows))
        elif args.cmd == "match": dump(service.match(json.loads(Path(args.json_file).read_text())))
        elif args.cmd == "discover": dump(service.discover_and_match(args.keyword, rows=args.rows))
        elif args.cmd == "nofo":
            result = service.nofo.parse_file(args.path); result.pop("text", None); dump(result)
        elif args.cmd == "project-create": dump(service.workspace.create_project(args.name, args.description))
        elif args.cmd == "evidence-add": dump(service.workspace.add_evidence(args.title, args.description, source=args.source, verified=args.verified))
        elif args.cmd == "grant-save": dump(service.workspace.save_grant(json.loads(Path(args.json_file).read_text())))
        elif args.cmd == "requirements-import": dump(service.workspace.import_nofo_requirements(args.grant_id, path=args.path))
        elif args.cmd == "proposal-create": dump(service.workspace.create_proposal(args.grant_id, args.project_id))
        elif args.cmd == "proposal-draft": dump(service.workspace.draft_proposal(args.proposal_id))
        elif args.cmd == "proposal-review": dump(service.workspace.review_proposal(args.proposal_id))
        elif args.cmd == "proposal-outcome": dump(service.workspace.record_outcome(args.proposal_id, args.outcome, award_amount=args.award_amount))
        else: parser.print_help()
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
