"""Broken Growth Ministries founder-stated facts that are safe to preload.
Unknown or contradictory details are intentionally left unanswered so GrantBot asks for them.
"""
SEED_ANSWERS = {
    "ORG_PUBLIC_NAME": "Broken Growth Ministries",
    "ORG_VISION": "BrokenGrowthMinistries envisions a Florida where incarceration and homelessness do not define a person's future, where every individual has access to a safe place to live, meaningful work, supportive community, and the opportunity to discover their God-given purpose.",
    "ORG_SERVICE_AREA": "The primary service focus is Pensacola and Escambia County, Florida, with a long-term goal of expanding statewide and eventually nationally.",
    "ORG_POPULATION_SERVED": "The organization is designed to serve adults age 18 and older who are recently released from jail or prison and people experiencing homelessness, including people facing chronic instability and barriers to housing and employment.",
    "PROGRAM_MODEL": "The planned integrated model combines transitional tiny-home housing, employment and workforce development, mentorship, life-skills development, resource navigation, community support, transportation assistance, and personal development so participants can move toward stability and independence.",
    "REENTRY_MODEL": "The reentry model is designed to begin before release when possible, continue through release-day transition, and combine housing, employment, mentorship, life skills, resource navigation, transportation support, and community support.",
    "REENTRY_PRE_RELEASE": "The organization plans to begin interviewing or engaging eligible participants as early as approximately six months before release when access and partner procedures allow.",
    "HOUSING_MODEL": "The planned housing model uses individual tiny homes as transitional housing within a supportive community, paired with employment, life skills, mentorship, and a pathway toward independent permanent housing.",
    "HOUSING_PLANNED_CAPACITY": "The initial concept is approximately 10 to 15 tiny homes, subject to site planning, zoning, permitting, funding, infrastructure, and final development decisions.",
    "WORKFORCE_MODEL": "Employment is a core part of the program model. The organization plans to connect participants to meaningful paid work, workforce development, job readiness, skills training, retention support, and advancement opportunities.",
    "WORKFORCE_JOB_TYPES": "Planned occupational pathways discussed include construction, landscaping, carpentry, plumbing, welding, food service, maintenance, and computer-related skills. Specific positions and employer commitments must be verified before use as existing opportunities.",
    "ORG_FAITH_BASED": "Broken Growth Ministries is faith-centered and Christian in orientation. The organization's vision includes helping people discover purpose while rebuilding stability, work, community, and independence.",
    "NEED_PRIMARY_PROBLEM": "The organization addresses the interconnected barriers of reentry after incarceration, homelessness, unstable housing, unemployment, poverty, and lack of coordinated supportive community resources.",
    "SUSTAINABILITY_REVENUE": "The long-term funding strategy under development includes public and private grants, individual and faith-community donations, partnerships, and appropriate earned-income or program revenue where legally and programmatically permitted.",
}

def seed_broken_growth(kb, overwrite=False):
    count = 0
    for qid, value in SEED_ANSWERS.items():
        if overwrite or kb.get(qid) is None:
            kb.set(qid, value, source="Broken Growth project context", provenance="FOUNDER_STATED", verified=True)
            count += 1
    return count
