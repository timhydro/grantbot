import json
import re
from datetime import datetime
from .db import db
from .models import Evidence, Project, Funder, GrantOpportunity, Requirement, Proposal, Outcome


def _json(value, default=None):
    if value in (None, ""):
        return default if default is not None else {}
    try:
        return json.loads(value)
    except (TypeError, json.JSONDecodeError):
        return default if default is not None else {}

class Workspace:
    def __init__(self, service):
        self.service = service

    def add_evidence(self, title, description, evidence_type="other", source=None, citation=None, verified=False, tags=None):
        item = Evidence(title=title.strip(), description=description.strip(), evidence_type=evidence_type, source=source, citation=citation, verified=bool(verified), tags=",".join(tags) if isinstance(tags, list) else tags)
        db.session.add(item); db.session.commit()
        return self.evidence_dict(item)

    def list_evidence(self, verified_only=False):
        q = Evidence.query
        if verified_only: q = q.filter_by(verified=True)
        return [self.evidence_dict(x) for x in q.order_by(Evidence.updated_at.desc()).all()]

    @staticmethod
    def evidence_dict(x):
        return {"id":x.id,"title":x.title,"type":x.evidence_type,"description":x.description,"source":x.source,"citation":x.citation,"verified":x.verified,"tags":x.tags}

    def create_project(self, name, description="", data=None):
        p = Project(name=name.strip(), description=description.strip(), data_json=json.dumps(data or {}, default=str))
        db.session.add(p); db.session.commit(); return self.project_dict(p)

    def list_projects(self):
        return [self.project_dict(p) for p in Project.query.order_by(Project.updated_at.desc()).all()]

    @staticmethod
    def project_dict(p):
        return {"id":p.id,"name":p.name,"description":p.description,"data":_json(p.data_json,{})}

    def save_grant(self, opportunity):
        agency = (opportunity.get("agency") or opportunity.get("agency_name") or "Unknown agency").strip()
        funder = Funder.query.filter_by(name=agency).first()
        if not funder:
            funder = Funder(name=agency, data_json="{}")
            db.session.add(funder); db.session.flush()
        number = opportunity.get("number") or opportunity.get("id") or opportunity.get("title")
        existing = GrantOpportunity.query.all()
        grant = None
        for item in existing:
            data = _json(item.data_json,{})
            if str(data.get("number") or data.get("id") or "") == str(number):
                grant = item; break
        deadline = self.service.matcher._parse_date(opportunity.get("close_date") or opportunity.get("deadline"))
        if not grant:
            grant = GrantOpportunity(funder_id=funder.id, name=(opportunity.get("title") or str(number)).strip(), deadline=deadline, data_json="{}")
            db.session.add(grant)
        grant.funder_id = funder.id
        grant.name = (opportunity.get("title") or grant.name).strip()
        grant.deadline = deadline
        stored = dict(opportunity)
        stored["match"] = self.service.match(opportunity)
        grant.data_json = json.dumps(stored, default=str)
        db.session.commit()
        return self.grant_dict(grant)

    def list_grants(self):
        return [self.grant_dict(g) for g in GrantOpportunity.query.order_by(GrantOpportunity.updated_at.desc()).all()]

    @staticmethod
    def grant_dict(g):
        data = _json(g.data_json,{})
        return {"db_id":g.id,"name":g.name,"deadline":g.deadline.isoformat() if g.deadline else None,"data":data}

    def import_nofo_requirements(self, grant_id, text=None, path=None):
        grant = db.session.get(GrantOpportunity, int(grant_id))
        if not grant: raise ValueError("Grant not found.")
        analysis = self.service.nofo.analyze(text) if text is not None else self.service.nofo.parse_file(path)
        created = []
        existing_prompts = {r.prompt for r in Requirement.query.filter_by(grant_id=grant.id).all()}
        for i, prompt in enumerate(analysis["requirements"], 1):
            if prompt in existing_prompts: continue
            category = self.service.mapper.classify(prompt)
            mapped = self.service.mapper.map(prompt, category)
            word_match = re.search(r"(?:maximum|limit|not exceed|up to)\s+(\d{2,5})\s+words?", prompt, flags=re.I)
            char_match = re.search(r"(?:maximum|limit|not exceed|up to)\s+(\d{2,7})\s+characters?", prompt, flags=re.I)
            req = Requirement(grant_id=grant.id, external_id=f"NOFO-{i:03d}", prompt=prompt, category=category, required=True, word_limit=int(word_match.group(1)) if word_match else None, character_limit=int(char_match.group(1)) if char_match else None, mapped_question_ids_json=json.dumps(mapped))
            db.session.add(req); db.session.flush(); created.append(self.requirement_dict(req))
        db.session.commit()
        return {"created":len(created),"requirements":created,"analysis":{"word_count":analysis["word_count"],"word_limits":analysis["word_limits"],"page_limits":analysis["page_limits"]}}

    def list_requirements(self, grant_id):
        return [self.requirement_dict(r) for r in Requirement.query.filter_by(grant_id=int(grant_id)).order_by(Requirement.id).all()]

    @staticmethod
    def requirement_dict(r):
        return {"id":r.id,"grant_id":r.grant_id,"external_id":r.external_id,"prompt":r.prompt,"category":r.category,"required":r.required,"word_limit":r.word_limit,"character_limit":r.character_limit,"weight":r.weight,"mapped_question_ids":_json(r.mapped_question_ids_json,[])}

    def create_proposal(self, grant_id, project_id=None, mode="enhanced"):
        grant = db.session.get(GrantOpportunity, int(grant_id))
        if not grant: raise ValueError("Grant not found.")
        if project_id is not None and not db.session.get(Project, int(project_id)): raise ValueError("Project not found.")
        version = (db.session.query(db.func.max(Proposal.version)).filter_by(grant_id=grant.id).scalar() or 0) + 1
        proposal = Proposal(grant_id=grant.id, project_id=int(project_id) if project_id is not None else None, version=version, mode=mode, status="draft", sections_json="{}", scores_json="{}")
        db.session.add(proposal); db.session.commit(); return self.proposal_dict(proposal)

    def draft_proposal(self, proposal_id):
        proposal = db.session.get(Proposal, int(proposal_id))
        if not proposal: raise ValueError("Proposal not found.")
        reqs = Requirement.query.filter_by(grant_id=proposal.grant_id).order_by(Requirement.id).all()
        if not reqs: raise ValueError("No requirements have been imported for this grant.")
        sections, scores = {}, {}
        for req in reqs:
            result = self.service.draft(req.prompt, category=req.category, mode=proposal.mode, word_limit=req.word_limit)
            sections[str(req.id)] = result["narrative"]
            scores[str(req.id)] = {"safe_to_submit":result["safe_to_submit"],"verification_needed":result["verification_needed"],"compliance":result["compliance"],"claim_check":result["claim_check"],"sufficiency":result["sufficiency"]}
        proposal.sections_json = json.dumps(sections, default=str)
        proposal.scores_json = json.dumps(scores, default=str)
        db.session.commit()
        return self.review_proposal(proposal.id)

    def set_section(self, proposal_id, requirement_id, text):
        proposal = db.session.get(Proposal, int(proposal_id)); req = db.session.get(Requirement, int(requirement_id))
        if not proposal or not req or req.grant_id != proposal.grant_id: raise ValueError("Proposal or requirement not found.")
        sections = _json(proposal.sections_json,{})
        sections[str(req.id)] = text.strip()
        proposal.sections_json = json.dumps(sections)
        db.session.commit()
        return self.review_proposal(proposal.id)

    def review_proposal(self, proposal_id):
        proposal = db.session.get(Proposal, int(proposal_id))
        if not proposal: raise ValueError("Proposal not found.")
        sections = _json(proposal.sections_json,{})
        reqs = {str(r.id):r for r in Requirement.query.filter_by(grant_id=proposal.grant_id).all()}
        section_reviews = {}
        missing_all = []
        safe_all = True
        for rid, req in reqs.items():
            text = sections.get(rid, "")
            mapped = _json(req.mapped_question_ids_json, []) or self.service.mapper.map(req.prompt, req.category)
            facts = self.service.kb.context(mapped, usable_only=True)
            missing = [qid for qid in mapped if qid not in facts]
            claims = self.service.claim_checker.check(text, list(facts.values()))
            compliance = self.service.compliance.check(text, req.word_limit, req.character_limit)
            safe = bool(text and not missing and claims["safe"] and compliance["passed"])
            safe_all = safe_all and safe
            missing_all.extend(missing)
            section_reviews[rid] = {"safe_to_submit":safe,"verification_needed":missing,"claim_check":claims,"compliance":compliance}
        consistency = self.service.consistency.compare({reqs[rid].external_id or rid: sections.get(rid,"") for rid in reqs})
        if consistency["conflicts"]: safe_all = False
        review = {"proposal":self.proposal_dict(proposal),"section_reviews":section_reviews,"verification_needed":sorted(set(missing_all)),"consistency":consistency,"safe_to_submit":safe_all}
        proposal.scores_json = json.dumps(review, default=str)
        db.session.commit()
        return review

    def record_outcome(self, proposal_id, outcome, reviewer_feedback=None, award_amount=None, submitted_at=None):
        proposal = db.session.get(Proposal, int(proposal_id))
        if not proposal: raise ValueError("Proposal not found.")
        out = Outcome(proposal_id=proposal.id, outcome=max(0.0,min(1.0,float(outcome))), reviewer_feedback=reviewer_feedback, award_amount=award_amount, submitted_at=submitted_at or datetime.utcnow())
        db.session.add(out); db.session.commit()
        text = " ".join(_json(proposal.sections_json,{}).values())
        self.service.ml.add_training_sample(text, out.outcome)
        self.service.ml.train()
        return {"id":out.id,"proposal_id":proposal.id,"outcome":out.outcome,"award_amount":out.award_amount}

    @staticmethod
    def proposal_dict(p):
        return {"id":p.id,"grant_id":p.grant_id,"project_id":p.project_id,"version":p.version,"status":p.status,"mode":p.mode,"sections":_json(p.sections_json,{}),"scores":_json(p.scores_json,{})}
