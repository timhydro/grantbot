import re

PLACEHOLDER_PATTERNS = [r"\[[^\]]*(?:add|insert|tbd|placeholder|verify)[^\]]*\]", r"\bTBD\b", r"\bTK\b"]
RISKY_ABSOLUTES = ["guarantee", "guaranteed", "eliminates recidivism", "100% success", "proven to"]

class ClaimChecker:
    def check(self, text, fact_values=None):
        text = text or ""
        facts = "\n".join(str(v) for v in (fact_values or []))
        issues = []
        placeholders = []
        for pat in PLACEHOLDER_PATTERNS:
            placeholders.extend(re.findall(pat, text, flags=re.I))
        if placeholders:
            issues.append("Draft contains unresolved placeholders.")

        # Numeric claims are high-risk when a model introduces numbers not present in source facts.
        numeric_claims = re.findall(r"(?<!\w)(?:\$\s*)?\d[\d,]*(?:\.\d+)?\s*(?:%|percent|people|participants|homes|units|jobs|years?|months?|days?)?", text, flags=re.I)
        fact_numbers = set(re.findall(r"\d[\d,]*(?:\.\d+)?", facts))
        unverified_numeric = []
        for claim in numeric_claims:
            numbers = re.findall(r"\d[\d,]*(?:\.\d+)?", claim)
            if numbers and any(n not in fact_numbers for n in numbers):
                unverified_numeric.append(claim.strip())
        if unverified_numeric:
            issues.append("Draft contains numeric claims not found in the supplied fact set.")

        risky = [phrase for phrase in RISKY_ABSOLUTES if phrase in text.lower()]
        if risky:
            issues.append("Draft contains an absolute or outcome claim requiring evidence.")
        return {
            "safe": not issues,
            "issues": issues,
            "placeholders": sorted(set(placeholders)),
            "unverified_numeric_claims": sorted(set(unverified_numeric)),
            "risky_absolute_claims": risky,
        }
