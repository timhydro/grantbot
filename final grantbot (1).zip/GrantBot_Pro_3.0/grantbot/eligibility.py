import re
from datetime import datetime

ACADEMIC = ("institution of higher education", "public and state controlled institutions of higher education", "private institutions of higher education", "university", "college", "postdoctoral", "doctoral", "research institution")
TRIBAL = ("native american tribal", "tribal organization", "indian housing", "tribally designated", "tribal governments")
GOV_ONLY = ("county governments", "city or township governments", "state governments", "special district governments", "public housing authorities")
NONPROFIT = ("nonprofits having a 501(c)(3)", "nonprofits that do not have a 501(c)(3)", "nonprofit")

class EligibilityEngine:
    @staticmethod
    def _types(opportunity):
        items = opportunity.get("applicant_types") or opportunity.get("applicantTypes") or []
        result = []
        for item in items:
            if isinstance(item, dict):
                result.append(str(item.get("description") or item.get("label") or ""))
            else:
                result.append(str(item))
        return [x.strip() for x in result if x.strip()]

    def evaluate(self, opportunity, org_context=None):
        org_context = org_context or {}
        types = self._types(opportunity)
        low_types = " | ".join(types).lower()
        text = " ".join(str(opportunity.get(k, "")) for k in ("title","description","synopsis","eligibility","additional_information")).lower()
        status = str(opportunity.get("status") or opportunity.get("oppStatus") or "").lower()
        reasons, warnings = [], []

        if status in {"closed", "archived"}:
            return {"eligible": False, "status": "REJECT", "hard_reject": True, "reasons": [f"Opportunity status is {status}."], "warnings": []}

        has_nonprofit = any(term in low_types for term in NONPROFIT)
        has_academic = any(term in low_types for term in ACADEMIC)
        has_tribal = any(term in low_types for term in TRIBAL)
        has_gov = any(term in low_types for term in GOV_ONLY)

        # Hard reject only when the listed applicant classes are clearly specialized and do not include nonprofit eligibility.
        if types and not has_nonprofit:
            if has_academic:
                reasons.append("Applicant eligibility is restricted to academic/research institutions.")
            if has_tribal:
                reasons.append("Applicant eligibility is restricted to Tribal entities.")
            if has_gov and all(any(term in t.lower() for term in GOV_ONLY) for t in types):
                reasons.append("Applicant eligibility is restricted to governmental/public entities.")
        if reasons:
            return {"eligible": False, "status": "REJECT", "hard_reject": True, "reasons": reasons, "warnings": []}

        if not types:
            warnings.append("Applicant eligibility was not identified; verify the official NOFO.")
        elif has_nonprofit:
            tax_status = (org_context.get("ORG_501C3_STATUS") or "").lower()
            requires_501 = "501(c)(3)" in low_types and "do not have" not in low_types
            if requires_501 and not tax_status:
                warnings.append("The opportunity lists 501(c)(3) nonprofits; the organization's IRS status must be verified before submission.")
            elif requires_501 and any(x in tax_status for x in ("pending", "not approved", "not yet", "application")):
                warnings.append("The opportunity may require approved 501(c)(3) status; current organization status appears pending or unconfirmed.")

        if "small business" in low_types and len(types) == 1:
            return {"eligible": False, "status": "REJECT", "hard_reject": True, "reasons": ["Applicant eligibility is restricted to small businesses."], "warnings": []}
        if any(x in text for x in ("doctoral fellowship", "postdoctoral fellowship")) and not has_nonprofit:
            return {"eligible": False, "status": "REJECT", "hard_reject": True, "reasons": ["Opportunity is a specialized academic fellowship."], "warnings": []}

        return {"eligible": None if warnings else True, "status": "VERIFY" if warnings else "PASS", "hard_reject": False, "reasons": reasons, "warnings": warnings}
