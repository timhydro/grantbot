import json
import os
import urllib.error
import urllib.request

class ProviderError(RuntimeError):
    pass

class OllamaProvider:
    """Local Ollama provider. No cloud key is required for a local Ollama server."""
    def __init__(self, model=None, base_url=None, timeout=120):
        self.model = model or os.getenv("GRANTBOT_OLLAMA_MODEL", "qwen3:8b")
        self.base_url = (base_url or os.getenv("GRANTBOT_OLLAMA_URL", "http://127.0.0.1:11434")).rstrip("/")
        self.timeout = timeout

    def available(self):
        try:
            with urllib.request.urlopen(f"{self.base_url}/api/tags", timeout=3) as r:
                return r.status == 200
        except Exception:
            return False

    def generate(self, system, prompt):
        payload = json.dumps({
            "model": self.model,
            "system": system,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": 0.2, "top_p": 0.9},
        }).encode("utf-8")
        req = urllib.request.Request(
            f"{self.base_url}/api/generate", data=payload,
            headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                data = json.loads(r.read().decode("utf-8"))
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            raise ProviderError(f"Ollama request failed: {exc}") from exc
        text = (data.get("response") or "").strip()
        if not text:
            raise ProviderError("Ollama returned an empty response.")
        return text
