import re
from .questions import QUESTION_MAP, MASTER_QUESTIONS

class AnswerSufficiencyEngine:
    """Deterministic completeness scoring; never treats style as factual truth."""
    def score(self, answer, expected_terms=None):
        answer = (answer or "").strip()
        words = len(answer.split())
        specificity = min(1.0, words / 120.0)
        structure = 1.0 if any(x in answer for x in [".", ";", "\n"]) else 0.4
        evidence = 1.0 if re.search(r"\d|according to|report|study|data|survey|source", answer, re.I) else 0.25
        relevance = 1.0
        if expected_terms:
            hits = sum(1 for term in expected_terms if term.lower() in answer.lower())
            relevance = hits / max(1, len(expected_terms))
        score = round((specificity*.30 + structure*.15 + evidence*.25 + relevance*.30) * 100, 1)
        gaps = []
        if words < 25: gaps.append("more specificity")
        if evidence < .5: gaps.append("supporting evidence or clearly labeled context")
        if expected_terms and relevance < .6: gaps.append("direct coverage of required concepts")
        return {"score": score, "gaps": gaps, "word_count": words}

class RequirementMapper:
    DOMAIN_TERMS = {
        "housing": ["housing","home","shelter","residential","tenant","tiny home","homeless"],
        "employment": ["employment","workforce","job","career","wage","training","credential","apprentice"],
        "reentry": ["reentry","incarcerat","prison","jail","justice","recidiv","probation","parole"],
        "need": ["need","problem","barrier","population","disparity","evidence","data"],
        "outcomes": ["outcome","measure","evaluation","goal","objective","result","performance"],
        "capacity": ["capacity","experience","staff","leadership","management","implementation"],
        "financial": ["budget","financial","cost","expense","revenue","match","cost share","indirect"],
        "sustainability": ["sustain","continuation","future funding","long-term"],
        "partnerships": ["partner","collaborat","mou","referral","stakeholder"],
        "governance": ["board","policy","compliance","conflict","internal control","privacy"],
        "organization": ["organization","mission","history","background","about"],
    }
    KEYWORD_QIDS = {
        "mission": ["ORG_MISSION"], "history": ["ORG_HISTORY"], "vision": ["ORG_VISION"],
        "budget": ["FIN_ANNUAL_BUDGET","FIN_EXPENSES","FIN_REVENUE","PROJECT_BUDGET_ASSUMPTIONS"],
        "match": ["FIN_MATCH"], "indirect": ["PROJECT_INDIRECT_RATE"],
        "transport": ["PROGRAM_TRANSPORTATION","WORKFORCE_RETENTION"],
        "recidiv": ["REENTRY_RECIVIDISM_OUTCOME","OUTCOMES_TARGETS"],
        "tiny home": ["HOUSING_MODEL","HOUSING_PLANNED_CAPACITY","HOUSING_COST_PER_UNIT"],
        "zoning": ["HOUSING_ZONING"], "land": ["HOUSING_LAND_STATUS"],
        "credential": ["WORKFORCE_CERTIFICATIONS"], "wage": ["WORKFORCE_WAGES"],
        "employer": ["WORKFORCE_EMPLOYERS"], "501": ["ORG_501C3_STATUS"],
        "sam": ["ORG_SAM_STATUS","ORG_UEI"], "conflict": ["GOV_CONFLICT_POLICY"],
    }

    def classify(self, prompt, category="other"):
        if category and category != "other":
            return category
        low = (prompt or "").lower()
        scores = {domain: sum(1 for t in terms if t in low) for domain, terms in self.DOMAIN_TERMS.items()}
        domain, score = max(scores.items(), key=lambda x: x[1])
        return domain if score else "organization"

    def map(self, prompt, category="other"):
        low = (prompt or "").lower()
        domain = self.classify(prompt, category)
        ids = list(QUESTION_MAP.get(domain, []))
        for term, mapped in self.KEYWORD_QIDS.items():
            if term in low:
                ids.extend(mapped)
        # Match explicit question vocabulary to improve recall without embeddings.
        for qid, qcat, question, _atype, _required in MASTER_QUESTIONS:
            qtokens = {w for w in re.findall(r"[a-z]{5,}", question.lower())}
            ptokens = set(re.findall(r"[a-z]{5,}", low))
            if len(qtokens & ptokens) >= 2:
                ids.append(qid)
        return list(dict.fromkeys(ids))

class PersuasionEngine:
    """Creates ethical funder-aligned structure while preserving fact boundaries."""
    def build_brief(self, answer, requirement, mode="enhanced"):
        analysis = AnswerSufficiencyEngine().score(answer)
        return {
            "mode": mode,
            "requirement": requirement,
            "recommended_structure": [
                "answer the requirement directly",
                "connect verified need to the proposed response",
                "use concrete verified facts and measurable targets where available",
                "show organizational capacity and partnership leverage",
                "close with funder-aligned public benefit",
            ],
            "gaps": analysis["gaps"],
            "provenance_policy": "never convert assumptions, plans, or missing data into established results",
        }
