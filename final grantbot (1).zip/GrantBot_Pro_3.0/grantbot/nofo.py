import re
from pathlib import Path

class NOFOParser:
    SUPPORTED = {".txt", ".md", ".pdf", ".docx"}

    def extract_text(self, path):
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(path)
        ext = path.suffix.lower()
        if ext not in self.SUPPORTED:
            raise ValueError(f"Unsupported NOFO format: {ext}")
        if ext in {".txt", ".md"}:
            return path.read_text(encoding="utf-8", errors="replace")
        if ext == ".pdf":
            from pypdf import PdfReader
            reader = PdfReader(str(path))
            return "\n".join((page.extract_text() or "") for page in reader.pages)
        from docx import Document
        doc = Document(str(path))
        return "\n".join(p.text for p in doc.paragraphs)

    def analyze(self, text):
        text = re.sub(r"\r", "", text or "")
        compact = re.sub(r"[ \t]+", " ", text)
        lines = [x.strip() for x in compact.splitlines() if x.strip()]
        chunks = []
        for line in lines:
            chunks.extend(x.strip() for x in re.split(r"(?<=[.!?])\s+", line) if x.strip())
        requirements = []
        patterns = ("must ", "shall ", "required", "applicant will", "applicants will", "should describe", "provide a", "submit a", "include a")
        for line in chunks:
            low = line.lower()
            if any(p in low for p in patterns) and 20 <= len(line) <= 1200:
                requirements.append(line)
        # De-duplicate while preserving order.
        requirements = list(dict.fromkeys(requirements))
        word_limits = [int(x) for x in re.findall(r"(?:maximum|limit|not exceed|up to)\s+(\d{2,5})\s+words?", text, flags=re.I)]
        page_limits = [int(x) for x in re.findall(r"(?:maximum|limit|not exceed|up to)\s+(\d{1,3})\s+pages?", text, flags=re.I)]
        return {
            "character_count": len(text), "word_count": len(text.split()),
            "requirements": requirements[:250],
            "word_limits": sorted(set(word_limits)), "page_limits": sorted(set(page_limits)),
        }

    def parse_file(self, path):
        text = self.extract_text(path)
        return {"path": str(path), **self.analyze(text), "text": text}
