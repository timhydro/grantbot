import json
from datetime import datetime
from .db import db
from .models import MasterAnswer
from .questions import MASTER_QUESTIONS

USABLE_PROVENANCE = {"APPROVED", "VERIFIED", "FOUNDER_STATED", "USER_FACT", "DOCUMENT_FACT"}

class KnowledgeBase:
    def __init__(self):
        self.questions = {
            q[0]: {"id": q[0], "category": q[1], "question": q[2], "type": q[3], "required": q[4], "reusable": True}
            for q in MASTER_QUESTIONS
        }

    def get_record(self, question_id):
        return (MasterAnswer.query.filter_by(question_id=question_id, valid_to=None)
                .order_by(MasterAnswer.updated_at.desc()).first())

    def get(self, question_id, usable_only=False):
        record = self.get_record(question_id)
        if not record:
            return None
        if usable_only and not self.is_usable(record):
            return None
        return record.value

    @staticmethod
    def is_usable(record):
        return bool(record and (record.verified or record.provenance in USABLE_PROVENANCE))

    def set(self, question_id, value, source="user", provenance="USER_FACT", verified=True, reusable=True):
        if question_id not in self.questions:
            raise ValueError(f"Unknown question ID: {question_id}")
        value = str(value).strip()
        if not value:
            raise ValueError("Answer cannot be blank.")
        old = self.get_record(question_id)
        if old:
            old.valid_to = datetime.utcnow()
        answer = MasterAnswer(
            question_id=question_id,
            value=value,
            answer_type=self.questions[question_id]["type"],
            source=source,
            provenance=provenance,
            verified=verified,
            reusable=reusable,
            last_verified=datetime.utcnow() if verified else None,
        )
        db.session.add(answer)
        db.session.commit()
        return answer

    def missing(self, required_only=False, usable_only=False):
        result = []
        for q in self.questions.values():
            if required_only and not q["required"]:
                continue
            if self.get(q["id"], usable_only=usable_only) is None:
                result.append(q)
        return result

    def status(self):
        total = len(self.questions)
        answered = sum(1 for qid in self.questions if self.get(qid) is not None)
        usable = sum(1 for qid in self.questions if self.get(qid, usable_only=True) is not None)
        required_ids = [qid for qid, q in self.questions.items() if q["required"]]
        required_usable = sum(1 for qid in required_ids if self.get(qid, usable_only=True) is not None)
        return {
            "total": total,
            "answered": answered,
            "usable": usable,
            "remaining": total - answered,
            "completion_percent": round(answered / total * 100, 1) if total else 100,
            "usable_completion_percent": round(usable / total * 100, 1) if total else 100,
            "required": len(required_ids),
            "required_remaining": len(required_ids) - required_usable,
            "required_completion_percent": round(required_usable / len(required_ids) * 100, 1) if required_ids else 100,
        }

    def context(self, question_ids=None, usable_only=True):
        ids = question_ids or list(self.questions)
        result = {}
        for qid in ids:
            value = self.get(qid, usable_only=usable_only)
            if value is not None:
                result[qid] = value
        return result

    def records(self, question_ids=None, usable_only=True):
        ids = question_ids or list(self.questions)
        result = {}
        for qid in ids:
            record = self.get_record(qid)
            if not record or (usable_only and not self.is_usable(record)):
                continue
            result[qid] = {
                "value": record.value,
                "source": record.source,
                "provenance": record.provenance,
                "verified": record.verified,
                "last_verified": record.last_verified.isoformat() if record.last_verified else None,
            }
        return result

    def export(self):
        result = {}
        for qid, q in self.questions.items():
            r = self.get_record(qid)
            result[qid] = {
                "category": q["category"], "question": q["question"], "required": q["required"],
                "answer": r.value if r else None,
                "source": r.source if r else None,
                "provenance": r.provenance if r else "MISSING",
                "verified": bool(r.verified) if r else False,
            }
        return result

    def import_answers(self, payload, default_source="import", default_provenance="DOCUMENT_FACT", verified=False):
        count = 0
        for qid, item in payload.items():
            if qid not in self.questions:
                continue
            if isinstance(item, dict):
                value = item.get("answer", item.get("value"))
                source = item.get("source", default_source)
                provenance = item.get("provenance", default_provenance)
                is_verified = bool(item.get("verified", verified))
            else:
                value, source, provenance, is_verified = item, default_source, default_provenance, verified
            if value not in (None, ""):
                self.set(qid, value, source=source, provenance=provenance, verified=is_verified)
                count += 1
        return count
