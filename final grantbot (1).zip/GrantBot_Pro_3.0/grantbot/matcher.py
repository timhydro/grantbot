import math
import re
from datetime import datetime, timezone
from .eligibility import EligibilityEngine

THEMES = {
    "reentry": {"weight": 24, "terms": ["reentry","re-entry","formerly incarcerated","justice involved","justice-involved","incarcerat","prison","jail","recidiv","correction"]},
    "homelessness": {"weight": 20, "terms": ["homeless","unsheltered","housing instability","continuum of care","coordinated entry"]},
    "housing": {"weight": 18, "terms": ["supportive housing","transitional housing","affordable housing","housing","tiny home","residential"]},
    "employment": {"weight": 16, "terms": ["employment","job placement","career","economic opportunity","wage","employer"]},
    "workforce": {"weight": 14, "terms": ["workforce development","job training","vocational","credential","apprenticeship","skills training"]},
    "supportive_services": {"weight": 8, "terms": ["supportive services","case management","mentoring","life skills","navigation","transportation"]},
}

class GrantMatcher:
    def __init__(self):
        self.eligibility = EligibilityEngine()

    @staticmethod
    def _text(opportunity):
        values = []
        for key in ("title","description","synopsis","agency","agency_name","funding_categories","additional_information"):
            val = opportunity.get(key)
            if isinstance(val, (list, tuple)):
                val = " ".join(str(x) for x in val)
            values.append(str(val or ""))
        return " ".join(values).lower()

    @staticmethod
    def _parse_date(value):
        if not value:
            return None
        if isinstance(value, datetime):
            return value
        for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%b %d, %Y", "%B %d, %Y", "%Y-%m-%d-%H-%M-%S"):
            try:
                return datetime.strptime(str(value).strip(), fmt)
            except ValueError:
                pass
        return None

    def score(self, opportunity, org_context=None, today=None):
        today = today or datetime.now()
        text = self._text(opportunity)
        elig = self.eligibility.evaluate(opportunity, org_context)
        if elig["hard_reject"]:
            return {"score": 0, "priority": "REJECT", "matched": [], "eligibility": elig, "deadline": self._deadline(opportunity, today), "warnings": elig["warnings"], "action": "Do not prioritize unless eligibility facts change."}

        matched = []
        theme_score = 0.0
        for name, spec in THEMES.items():
            hits = [term for term in spec["terms"] if term in text]
            if hits:
                # Full theme credit once signal is clear; extra hits strengthen explanation, not score inflation.
                theme_score += spec["weight"]
                matched.append({"theme": name, "weight": spec["weight"], "hits": hits[:5]})
        theme_score = min(100.0, theme_score)

        deadline = self._deadline(opportunity, today)
        if deadline["days_remaining"] is None:
            deadline_factor = 0.85
        elif deadline["days_remaining"] < 0:
            return {"score": 0, "priority": "REJECT", "matched": matched, "eligibility": elig, "deadline": deadline, "warnings": elig["warnings"] + ["Deadline has passed."], "action": "Do not pursue this cycle."}
        elif deadline["days_remaining"] <= 7:
            deadline_factor = 0.72
        elif deadline["days_remaining"] <= 21:
            deadline_factor = 0.90
        else:
            deadline_factor = 1.0

        eligibility_factor = 1.0 if elig["status"] == "PASS" else 0.88
        score = round(theme_score * deadline_factor * eligibility_factor)
        if score >= 80: priority = "HIGH"
        elif score >= 60: priority = "MEDIUM"
        elif score >= 40: priority = "LOW"
        else: priority = "REJECT"
        warnings = list(elig["warnings"])
        if not opportunity.get("agency") and not opportunity.get("agency_name"):
            warnings.append("Funding agency not identified.")
        if deadline["days_remaining"] is None:
            warnings.append("Deadline was not identified.")
        action = {
            "HIGH": "Prioritize: verify full eligibility and begin the application checklist.",
            "MEDIUM": "Investigate: verify eligibility, fit, and required match before committing staff time.",
            "LOW": "Low priority: pursue only if the full NOFO reveals stronger alignment.",
            "REJECT": "Do not prioritize unless fit or eligibility facts change.",
        }[priority]
        return {"score": score, "priority": priority, "matched": matched, "eligibility": elig, "deadline": deadline, "warnings": warnings, "action": action}

    def _deadline(self, opportunity, today):
        raw = opportunity.get("close_date") or opportunity.get("deadline") or opportunity.get("closeDate")
        dt = self._parse_date(raw)
        if not dt:
            return {"date": raw or None, "days_remaining": None, "priority": "UNKNOWN"}
        days = (dt.date() - today.date()).days
        if days < 0: level = "CLOSED"
        elif days <= 7: level = "URGENT"
        elif days <= 30: level = "HIGH"
        elif days <= 60: level = "MEDIUM"
        else: level = "NORMAL"
        return {"date": dt.date().isoformat(), "days_remaining": days, "priority": level}
