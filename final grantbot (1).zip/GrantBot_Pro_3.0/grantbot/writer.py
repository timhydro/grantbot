import os
import re
from .analysis import RequirementMapper, AnswerSufficiencyEngine
from .claim_checker import ClaimChecker
from .ai.providers import OllamaProvider, ProviderError

DOMAIN_LABELS = {
    "housing": "housing stability",
    "employment": "employment and workforce development",
    "reentry": "successful community reentry",
    "need": "documented community need",
    "outcomes": "measurable outcomes",
    "capacity": "organizational capacity",
    "financial": "financial stewardship",
    "sustainability": "long-term sustainability",
    "partnerships": "collaborative implementation",
    "governance": "governance and compliance",
    "organization": "the organization's mission and program model",
}

class GrantWriter:
    def __init__(self, knowledge_base=None, provider=None):
        self.kb = knowledge_base
        self.mapper = RequirementMapper()
        self.sufficiency = AnswerSufficiencyEngine()
        self.claim_checker = ClaimChecker()
        self.provider = provider

    def _relevant_records(self, requirement, category="other"):
        qids = self.mapper.map(requirement, category)
        records = self.kb.records(qids, usable_only=True) if self.kb else {}
        return qids, records

    @staticmethod
    def _clean_fact(value):
        return re.sub(r"\s+", " ", (value or "").strip()).strip(" -")

    def _rule_based(self, requirement, records, category, extra_facts=None):
        facts = [self._clean_fact(v["value"]) for v in records.values() if self._clean_fact(v["value"])]
        facts.extend(self._clean_fact(v) for v in (extra_facts or []) if self._clean_fact(v))
        if not facts:
            return ""
        domain = self.mapper.classify(requirement, category)
        # Preserve factual wording; only add neutral connective language.
        if len(facts) == 1:
            return facts[0]
        lead = f"Broken Growth Ministries addresses this requirement through {DOMAIN_LABELS.get(domain, 'its integrated service model')}."
        body = " ".join(f if f.endswith((".", "!", "?")) else f + "." for f in facts[:8])
        return f"{lead} {body}".strip()

    def _ollama(self, requirement, records, category, word_limit=None, extra_facts=None):
        fact_lines = []
        for qid, record in records.items():
            fact_lines.append(f"- {qid} [{record['provenance']}]: {record['value']}")
        for i, fact in enumerate(extra_facts or [], 1):
            fact_lines.append(f"- EVIDENCE_{i} [VERIFIED_EVIDENCE]: {fact}")
        limit = f" Keep the response at or below {word_limit} words." if word_limit else ""
        system = (
            "You are GrantBot Pro, an expert nonprofit grant writer. Write clear, persuasive, ethical grant language. "
            "Use ONLY the supplied facts. Never invent statistics, partners, awards, budgets, outcomes, legal status, staff, dates, or program details. "
            "Distinguish planned activities from current accomplishments. Do not use placeholders. Avoid hype and guarantees." + limit
        )
        prompt = f"GRANT REQUIREMENT:\n{requirement}\n\nAUTHORIZED FACTS:\n" + "\n".join(fact_lines)
        return self.provider.generate(system, prompt)

    def draft_section(self, requirement, answer="", category="other", mode="enhanced", word_limit=None, extra_facts=None):
        mapped, records = self._relevant_records(requirement, category)
        missing = [qid for qid in mapped if qid not in records]
        facts_used = [r["value"] for r in records.values()] + list(extra_facts or [])

        if mode == "factual" and answer.strip():
            draft = answer.strip()
        elif self.provider and records:
            try:
                draft = self._ollama(requirement, records, category, word_limit, extra_facts=extra_facts)
            except ProviderError:
                draft = self._rule_based(requirement, records, category, extra_facts=extra_facts)
        else:
            draft = self._rule_based(requirement, records, category, extra_facts=extra_facts)

        if answer.strip() and answer.strip() not in draft:
            # User-supplied draft is allowed, but remains subject to claim checking.
            draft = (answer.strip() + " " + draft).strip()

        if word_limit and len(draft.split()) > word_limit:
            draft = " ".join(draft.split()[:word_limit]).rstrip(" ,;:") + "."

        checker = self.claim_checker.check(draft, facts_used + ([answer] if answer else []))
        sufficiency = self.sufficiency.score(draft)
        return {
            "narrative": draft,
            "facts_used": facts_used,
            "mapped_question_ids": mapped,
            "verification_needed": missing,
            "claim_check": checker,
            "sufficiency": sufficiency,
            "safe_to_submit": bool(draft and checker["safe"] and not missing),
        }


def build_default_writer(kb):
    provider_name = os.getenv("GRANTBOT_AI_PROVIDER", "rules").strip().lower()
    provider = OllamaProvider() if provider_name == "ollama" else None
    return GrantWriter(kb, provider=provider)
