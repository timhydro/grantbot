import re

class BudgetEngine:
    def normalize(self, items):
        clean = []
        for i, item in enumerate(items or [], 1):
            category = str(item.get("category") or "Uncategorized").strip()
            description = str(item.get("description") or item.get("name") or f"Line {i}").strip()
            quantity = float(item.get("quantity", 1) or 1)
            unit_cost = float(item.get("unit_cost", item.get("amount", 0)) or 0)
            amount = float(item.get("amount", quantity * unit_cost) or 0)
            if "amount" not in item:
                amount = quantity * unit_cost
            clean.append({"category": category, "description": description, "quantity": quantity, "unit_cost": round(unit_cost, 2), "amount": round(amount, 2)})
        return clean

    def total(self, items):
        return round(sum(x["amount"] for x in self.normalize(items)), 2)

    def by_category(self, items):
        totals = {}
        for item in self.normalize(items):
            totals[item["category"]] = round(totals.get(item["category"], 0) + item["amount"], 2)
        return totals

    def reconcile(self, narrative, items, requested_amount=None, match_required=None):
        clean = self.normalize(items)
        total = round(sum(x["amount"] for x in clean), 2)
        issues = []
        if requested_amount is not None and abs(total - float(requested_amount)) > 0.01:
            issues.append(f"Budget total ${total:,.2f} does not equal requested amount ${float(requested_amount):,.2f}.")
        if any(x["amount"] < 0 for x in clean):
            issues.append("Budget contains a negative line item.")
        narrative_numbers = {x.replace(",", "") for x in re.findall(r"\$\s*([\d,]+(?:\.\d{1,2})?)", narrative or "")}
        mentioned_total = f"{total:.2f}" in narrative_numbers or str(int(total)) in narrative_numbers
        if narrative and not mentioned_total:
            issues.append("Budget narrative does not explicitly state the calculated total.")
        if match_required is not None and float(match_required) < 0:
            issues.append("Required match cannot be negative.")
        return {"budget_total": total, "line_items": clean, "category_totals": self.by_category(clean), "narrative_contains_total": mentioned_total, "issues": issues, "passed": not issues}
