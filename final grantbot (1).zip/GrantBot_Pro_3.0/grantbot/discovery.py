import json
import urllib.error
import urllib.request

class GrantsGovError(RuntimeError):
    pass

class GrantsGovClient:
    BASE_URL = "https://api.grants.gov/v1/api"

    def __init__(self, timeout=30, opener=None):
        self.timeout = timeout
        self.opener = opener or urllib.request.urlopen

    def _post(self, endpoint, payload):
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(f"{self.BASE_URL}/{endpoint}", data=body, headers={"Content-Type": "application/json", "User-Agent": "GrantBot-Pro/3.0"}, method="POST")
        try:
            with self.opener(req, timeout=self.timeout) as response:
                data = json.loads(response.read().decode("utf-8"))
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            raise GrantsGovError(f"Grants.gov request failed: {exc}") from exc
        if data.get("errorcode") not in (None, 0):
            raise GrantsGovError(data.get("msg") or "Grants.gov returned an error.")
        return data

    def search(self, keyword, rows=25, statuses=("forecasted","posted"), start=0):
        rows = max(1, min(int(rows), 100))
        payload = {"rows": rows, "keyword": keyword or "", "oppStatuses": "|".join(statuses), "startRecordNum": max(0, int(start))}
        data = self._post("search2", payload)
        hits = (data.get("data") or {}).get("oppHits") or []
        return [self.normalize_search_hit(hit) for hit in hits]

    def fetch(self, opportunity_id):
        data = self._post("fetchOpportunity", {"opportunityId": int(opportunity_id)})
        return self.normalize_detail(data.get("data") or {})

    @staticmethod
    def normalize_search_hit(hit):
        return {
            "id": str(hit.get("id") or ""),
            "number": hit.get("number") or "",
            "title": hit.get("title") or "",
            "agency": hit.get("agencyName") or hit.get("agencyCode") or "",
            "agency_code": hit.get("agencyCode") or "",
            "open_date": hit.get("openDate") or None,
            "close_date": hit.get("closeDate") or None,
            "status": hit.get("oppStatus") or "",
            "aln": hit.get("alnist") or [],
            "raw": hit,
        }

    @staticmethod
    def normalize_detail(data):
        synopsis = data.get("synopsis") or {}
        applicant_types = synopsis.get("applicantTypes") or []
        funding_categories = synopsis.get("fundingActivityCategories") or []
        attachments = []
        for folder in data.get("synopsisAttachmentFolders") or []:
            for item in folder.get("synopsisAttachments") or []:
                attachments.append({
                    "id": item.get("id"), "file_name": item.get("fileName"),
                    "mime_type": item.get("mimeType"), "description": item.get("fileDescription"),
                })
        return {
            "id": str(data.get("id") or synopsis.get("opportunityId") or ""),
            "number": data.get("opportunityNumber") or "",
            "title": data.get("opportunityTitle") or "",
            "agency": synopsis.get("agencyName") or (data.get("agencyDetails") or {}).get("agencyName") or "",
            "agency_code": synopsis.get("agencyCode") or data.get("owningAgencyCode") or "",
            "description": synopsis.get("synopsisDesc") or "",
            "status": "posted" if data.get("docType") == "synopsis" else str(data.get("docType") or ""),
            "open_date": synopsis.get("postingDateStr") or synopsis.get("postingDate") or None,
            "close_date": synopsis.get("responseDate") or synopsis.get("responseDateDesc") or data.get("originalDueDateDesc") or None,
            "award_floor": synopsis.get("awardFloor") or None,
            "award_ceiling": synopsis.get("awardCeiling") or None,
            "cost_sharing": synopsis.get("costSharing"),
            "applicant_types": applicant_types,
            "funding_categories": [x.get("description") if isinstance(x, dict) else x for x in funding_categories],
            "aln": [x.get("alnNumber") for x in data.get("alns") or [] if isinstance(x, dict)],
            "attachments": attachments,
            "document_urls": data.get("synopsisDocumentURLs") or [],
            "raw": data,
        }
