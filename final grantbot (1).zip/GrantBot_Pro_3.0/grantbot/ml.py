from pathlib import Path
import pickle

class GrantMLEngine:
    FEATURES = ["word_count","numbers","power_words","emotional_strength","partnerships","match_score","requirement_coverage","evidence_density","outcome_specificity","budget_alignment","funder_alignment","rubric_coverage","sustainability_strength"]
    POWER_WORDS = ["impact","transform","community","opportunity","sustainable","equitable","measurable","outcomes","dignity","access","empower","strengthen","collaboration","effective"]

    def __init__(self, model_path="models/grant_ml.pkl"):
        self.model_path=Path(model_path); self.model=None; self.training_samples=[]; self.load()

    def extract_features(self, text, grant=None, metrics=None):
        grant=grant or {}; metrics=metrics or {}; lower=(text or "").lower()
        return {"word_count":len((text or "").split()),"numbers":sum(c.isdigit() for c in (text or "")),"power_words":sum(lower.count(w) for w in self.POWER_WORDS),"emotional_strength":sum(lower.count(w) for w in ["hope","future","dignity","story","journey"]),"partnerships":lower.count("partner")+lower.count("collaboration"),"match_score":float(grant.get("match_score",.5)),"requirement_coverage":float(metrics.get("requirement_coverage",0)),"evidence_density":float(metrics.get("evidence_density",0)),"outcome_specificity":float(metrics.get("outcome_specificity",0)),"budget_alignment":float(metrics.get("budget_alignment",0)),"funder_alignment":float(metrics.get("funder_alignment",0)),"rubric_coverage":float(metrics.get("rubric_coverage",0)),"sustainability_strength":float(metrics.get("sustainability_strength",0))}

    def heuristic(self, text, grant=None, metrics=None):
        f=self.extract_features(text,grant,metrics)
        length=min(1.0,f["word_count"]/400.0)
        evidence=min(1.0,(f["numbers"]+f["partnerships"]+f["power_words"])/20.0)
        supplied=[f[k] for k in ("requirement_coverage","evidence_density","outcome_specificity","budget_alignment","funder_alignment","rubric_coverage","sustainability_strength")]
        metric_strength=sum(supplied)/len(supplied) if any(supplied) else 0.35
        return round(max(0.0,min(1.0,0.25*length+0.25*evidence+0.50*metric_strength)),4)

    def train(self):
        if len(self.training_samples)<5: return False
        try:
            from sklearn.ensemble import RandomForestRegressor
        except ImportError: return False
        X=[[s["features"].get(k,0) for k in self.FEATURES] for s in self.training_samples]; y=[s["outcome"] for s in self.training_samples]
        self.model=RandomForestRegressor(n_estimators=200,random_state=42,min_samples_leaf=2); self.model.fit(X,y); self.save(); return True

    def add_training_sample(self,text,outcome,grant=None,metrics=None):
        self.training_samples.append({"features":self.extract_features(text,grant,metrics),"outcome":max(0.0,min(1.0,float(outcome)))})
        self.save()

    def predict(self,text,grant=None,metrics=None):
        if self.model is None: return {"score":self.heuristic(text,grant,metrics),"method":"heuristic","historical_samples":len(self.training_samples)}
        x=[[self.extract_features(text,grant,metrics).get(k,0) for k in self.FEATURES]]
        return {"score":max(0.0,min(1.0,float(self.model.predict(x)[0]))),"method":"trained_random_forest","historical_samples":len(self.training_samples)}

    def feature_importance(self):
        if not self.model or not hasattr(self.model,"feature_importances_"): return {}
        return dict(zip(self.FEATURES,map(float,self.model.feature_importances_)))

    def save(self):
        self.model_path.parent.mkdir(parents=True,exist_ok=True)
        with self.model_path.open("wb") as f: pickle.dump({"model":self.model,"samples":self.training_samples},f)

    def load(self):
        if not self.model_path.exists(): return False
        try:
            with self.model_path.open("rb") as f: p=pickle.load(f)
            self.model=p.get("model"); self.training_samples=p.get("samples",[]); return True
        except Exception:
            self.model=None; self.training_samples=[]; return False
