import json
from .db import db
from .models import AuditEvent, Evidence
from .knowledge import KnowledgeBase
from .analysis import RequirementMapper, AnswerSufficiencyEngine
from .writer import build_default_writer
from .compliance import ComplianceEngine, ConsistencyEngine
from .budget import BudgetEngine
from .ml import GrantMLEngine
from .matcher import GrantMatcher
from .discovery import GrantsGovClient
from .nofo import NOFOParser
from .claim_checker import ClaimChecker
from .seed import seed_broken_growth
from .workspace import Workspace

class GrantBotService:
    def __init__(self):
        self.kb = KnowledgeBase()
        self.mapper = RequirementMapper()
        self.sufficiency = AnswerSufficiencyEngine()
        self.writer = build_default_writer(self.kb)
        self.compliance = ComplianceEngine()
        self.consistency = ConsistencyEngine()
        self.budget = BudgetEngine()
        self.ml = GrantMLEngine()
        self.matcher = GrantMatcher()
        self.discovery = GrantsGovClient()
        self.nofo = NOFOParser()
        self.claim_checker = ClaimChecker()
        self.workspace = Workspace(self)

    def audit(self, event_type, message, entity_type=None, entity_id=None, data=None):
        db.session.add(AuditEvent(event_type=event_type, entity_type=entity_type, entity_id=str(entity_id) if entity_id is not None else None, message=message, data_json=json.dumps(data or {}, default=str)))
        db.session.commit()

    def seed(self, overwrite=False):
        count = seed_broken_growth(self.kb, overwrite=overwrite)
        self.audit("knowledge_seeded", f"Seeded {count} Broken Growth facts.")
        return {"seeded": count, "status": self.kb.status()}

    def analyze_requirement(self, prompt, category="other"):
        mapped = self.mapper.map(prompt, category)
        missing = [qid for qid in mapped if self.kb.get(qid, usable_only=True) is None]
        return {"category": self.mapper.classify(prompt, category), "mapped_question_ids": mapped, "missing_question_ids": missing, "questions": [self.kb.questions[qid] for qid in missing]}

    def _evidence_context(self, prompt, limit=5):
        tokens = {x for x in __import__("re").findall(r"[a-z]{5,}", (prompt or "").lower())}
        ranked = []
        for item in Evidence.query.filter_by(verified=True).all():
            text = " ".join(filter(None, [item.title, item.description, item.citation, item.tags])).lower()
            score = sum(1 for t in tokens if t in text)
            if score:
                label = item.description.strip()
                if item.citation: label += f" Source: {item.citation.strip()}"
                ranked.append((score, label))
        ranked.sort(key=lambda x: x[0], reverse=True)
        return [text for _score, text in ranked[:limit]]

    def draft(self, prompt, answer="", category="other", mode="enhanced", word_limit=None):
        domain = self.mapper.classify(prompt, category)
        evidence = self._evidence_context(prompt) if domain in {"need", "outcomes", "capacity", "organization"} else []
        result = self.writer.draft_section(prompt, answer, category=category, mode=mode, word_limit=word_limit, extra_facts=evidence)
        result["compliance"] = self.compliance.check(result["narrative"], word_limit=word_limit)
        result["evidence_used"] = evidence
        return result

    def match(self, opportunity):
        return self.matcher.score(opportunity, self.kb.context(usable_only=True))

    def discover_and_match(self, keyword, rows=25):
        opportunities = self.discovery.search(keyword, rows=rows)
        return [{**opp, "match": self.match(opp)} for opp in opportunities]

    def readiness(self, text, requirement_metrics=None):
        metrics = requirement_metrics or {}
        features = self.ml.extract_features(text, metrics=metrics)
        score = self.ml.predict(text, metrics=metrics)
        return {"prediction": score, "features": features, "feature_importance": self.ml.feature_importance()}
