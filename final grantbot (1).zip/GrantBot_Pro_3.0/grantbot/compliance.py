import re

class ComplianceEngine:
    def check(self, text, word_limit=None, character_limit=None, required_terms=None, prohibited_terms=None):
        text = text or ""
        words = len(text.split())
        chars = len(text)
        issues = []
        if word_limit and words > int(word_limit): issues.append(f"Word limit exceeded by {words-int(word_limit)} words.")
        if character_limit and chars > int(character_limit): issues.append(f"Character limit exceeded by {chars-int(character_limit)} characters.")
        missing = [term for term in (required_terms or []) if term.lower() not in text.lower()]
        prohibited = [term for term in (prohibited_terms or []) if term.lower() in text.lower()]
        if missing: issues.append("Missing required concepts: " + ", ".join(missing))
        if prohibited: issues.append("Contains prohibited concepts: " + ", ".join(prohibited))
        return {"passed": not issues, "word_count": words, "character_count": chars, "issues": issues, "missing_terms": missing, "prohibited_terms": prohibited}

class ConsistencyEngine:
    MONEY = re.compile(r"\$\s*([\d,]+(?:\.\d{1,2})?)")
    PERCENT = re.compile(r"\b(\d+(?:\.\d+)?)\s*%")

    def compare(self, sections):
        numeric_mentions, value_contexts = {}, {}
        for name, text in (sections or {}).items():
            text = text or ""
            for token in re.findall(r"(?<!\w)\$?\d[\d,]*(?:\.\d+)?%?", text):
                numeric_mentions.setdefault(token, []).append(name)
            # Capture common labeled metrics to expose contradictory values.
            for label in ("participants", "homes", "units", "jobs", "budget", "match", "wage"):
                for m in re.finditer(rf"(.{{0,35}}\b{label}\b.{{0,35}})", text, flags=re.I):
                    vals = re.findall(r"\$?\d[\d,]*(?:\.\d+)?%?", m.group(1))
                    for val in vals:
                        value_contexts.setdefault(label, {}).setdefault(val, []).append(name)
        conflicts = []
        for label, values in value_contexts.items():
            if len(values) > 1:
                conflicts.append({"metric": label, "values": values})
        return {"numeric_mentions": numeric_mentions, "conflicts": conflicts}
