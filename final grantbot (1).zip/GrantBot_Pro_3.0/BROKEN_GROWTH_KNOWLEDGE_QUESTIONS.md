# Broken Growth Ministries — Complete Knowledge Base Questions

## Organization

1. **ORG_LEGAL_NAME** — What is the organization's exact legal name as shown on its formation documents?

2. **ORG_PUBLIC_NAME** — What public or DBA name does the organization use?

## Legal

3. **ORG_EIN** — What is the organization's EIN?

4. **ORG_FORMATION_DATE** — What is the organization's legal formation date?

5. **ORG_STATE_REGISTRATION** — What state registration or document number identifies the organization?

6. **ORG_501C3_STATUS** — What is the organization's current IRS 501(c)(3) status, including determination date if approved or application status if pending?

7. **ORG_UEI** — What is the organization's Unique Entity ID (UEI), if registered in SAM.gov?

8. **ORG_SAM_STATUS** — What is the organization's current SAM.gov registration status and expiration date?

## Organization

9. **ORG_ADDRESS** — What is the organization's official mailing address?

10. **ORG_SERVICE_LOCATION** — What physical locations or facilities does the organization currently use to deliver services?

11. **ORG_CONTACT** — Who is the primary grant contact and what are the approved phone and email details?

12. **ORG_WEBSITE** — What is the organization's official website or public information page?

## Mission

13. **ORG_MISSION** — What is the final board-approved mission statement?

14. **ORG_VISION** — What is the final approved vision statement?

15. **ORG_VALUES** — What core values guide the organization?

## History

16. **ORG_HISTORY** — Describe the organization's history, origin, and development.

17. **ORG_FOUNDING_STORY** — What founder story or lived-experience background may be used publicly in grant narratives?

## Faith

18. **ORG_FAITH_BASED** — Is the organization faith-based, and how is faith incorporated into services?

19. **ORG_RELIGIOUS_PARTICIPATION** — Are religious activities voluntary, required, or separate from publicly funded services? Explain.

## Governance

20. **GOV_BOARD** — List current board members, offices, independence, and relevant expertise.

21. **GOV_MEETING_FREQUENCY** — How often does the board meet and how are minutes maintained?

22. **GOV_CONFLICT_POLICY** — Has the organization adopted a written conflict-of-interest policy and annual disclosure process?

23. **GOV_FINANCIAL_CONTROLS** — Describe written financial controls, spending authority, approvals, receipts, reconciliations, and segregation of duties.

24. **GOV_WHISTLEBLOWER** — Does the organization have a whistleblower policy?

25. **GOV_RECORD_RETENTION** — Does the organization have a document retention and destruction policy?

26. **GOV_NONDISCRIMINATION** — What nondiscrimination and equal-access policies apply to participants, employees, and volunteers?

27. **GOV_SAFEGUARDING** — What participant safeguarding, abuse-prevention, grievance, and incident-reporting procedures are in place?

28. **GOV_DATA_PRIVACY** — What privacy, confidentiality, consent, and data-security practices protect participant information?

29. **GOV_INSURANCE** — What insurance coverage does the organization carry or plan to carry?

## Leadership

30. **ORG_LEADERSHIP** — Who are the organization's key leaders and what relevant experience do they bring?

## Staff

31. **ORG_STAFF** — List current paid staff, roles, FTE status, and relevant qualifications.

32. **ORG_VOLUNTEERS** — How many volunteers support the organization and what roles do they perform?

33. **ORG_STAFF_PLAN** — What staff positions must be hired to implement the next phase of programs?

34. **ORG_BACKGROUND_CHECKS** — What background-check, screening, and training procedures apply to staff and volunteers?

## Community

35. **ORG_SERVICE_AREA** — What geographic area does the organization currently serve and where does it plan to expand?

## Population

36. **ORG_POPULATION_SERVED** — Who does the organization primarily serve? Include age, reentry/homelessness status, and other eligibility factors.

37. **ORG_ANNUAL_PEOPLE_SERVED** — How many unduplicated people are currently served annually?

38. **ORG_PROJECTED_PEOPLE_SERVED** — How many unduplicated people are projected to be served in the next 12 months?

39. **CLIENT_ELIGIBILITY** — What are the formal participant eligibility and exclusion criteria?

40. **CLIENT_INTAKE** — Describe referral, pre-release outreach, screening, intake, assessment, and enrollment procedures.

41. **CLIENT_SOBRIETY_POLICY** — What substance-use, sobriety, relapse, testing, and recovery-support policies apply to participants?

42. **CLIENT_ACCESSIBILITY** — How will services accommodate people with disabilities, limited English proficiency, literacy barriers, or transportation barriers?

## Programs

43. **ORG_PROGRAMS** — List every current program and service, distinguishing current operations from planned activities.

44. **PROGRAM_MODEL** — Describe the complete service model from referral or release through stable independence.

45. **PROGRAM_DOSAGE** — How often and for how long does each participant receive each major service?

46. **PROGRAM_CASE_MANAGEMENT** — Describe case management, service planning, referrals, and follow-up.

47. **PROGRAM_LIFE_SKILLS** — What life-skills curriculum or topics are provided, by whom, and at what frequency?

48. **PROGRAM_MENTORSHIP** — How is mentorship structured, matched, supervised, and measured?

49. **PROGRAM_TRANSPORTATION** — What transportation assistance is currently provided or planned?

50. **PROGRAM_RESOURCE_NAV** — What benefits, identification, legal, healthcare, behavioral-health, and community-resource navigation is provided?

## Reentry

51. **REENTRY_MODEL** — Describe the reentry program from pre-release engagement through community stabilization.

52. **REENTRY_PRE_RELEASE** — How far before release can engagement begin and what activities occur before release?

53. **REENTRY_RELEASE_DAY** — What happens on a participant's release day, including pickup, housing, identification, food, and employment steps?

54. **REENTRY_SUPERVISION_COORDINATION** — How will the program coordinate with probation, parole, corrections, courts, or reentry partners when appropriate?

55. **REENTRY_RECIVIDISM_OUTCOME** — How will recidivism or justice-system re-contact be defined, measured, and reported?

## Housing

56. **HOUSING_MODEL** — Describe the housing model, including tiny homes, transitional housing, supportive services, and resident progression.

57. **HOUSING_CURRENT_CAPACITY** — How many housing units and beds are currently operational?

58. **HOUSING_PLANNED_CAPACITY** — How many housing units and beds are planned in the next phase?

59. **HOUSING_LAND_STATUS** — What land or property is available, who owns it, and what lease or use agreements exist?

60. **HOUSING_ZONING** — What zoning, permitting, utilities, environmental, building-code, and site-development approvals are required or completed?

61. **HOUSING_COST_PER_UNIT** — What is the estimated all-in development cost per housing unit and how was it calculated?

62. **HOUSING_LENGTH_STAY** — What is the expected or maximum length of stay?

63. **HOUSING_FEES** — Will residents pay rent, program fees, utilities, savings contributions, or another share of income? Explain the policy.

64. **HOUSING_RULES** — What resident agreement, chores, guest, safety, curfew, substance-use, and discharge rules apply?

65. **HOUSING_EXIT_PLAN** — How does the program help residents transition to permanent independent housing?

## Employment

66. **WORKFORCE_MODEL** — Describe the workforce and employment model from assessment through placement, retention, and advancement.

67. **WORKFORCE_JOB_TYPES** — What jobs, trades, or occupational pathways are currently offered or planned?

68. **WORKFORCE_POSITIONS** — How many paid positions or placements are currently available and projected?

69. **WORKFORCE_WAGES** — What starting wages, hours, benefits, and employment classifications apply?

70. **WORKFORCE_TRAINING** — What job-readiness, technical, apprenticeship, or on-the-job training is provided?

71. **WORKFORCE_CERTIFICATIONS** — What industry-recognized credentials or certifications can participants earn?

72. **WORKFORCE_EMPLOYERS** — Which employers have formal or informal hiring partnerships and what commitments exist?

73. **WORKFORCE_RETENTION** — What retention, coaching, transportation, equipment, and advancement support is provided after placement?

74. **WORKFORCE_OUTCOMES** — What employment placement, wage, retention, credential, and advancement results have been achieved?

## Need

75. **NEED_PRIMARY_PROBLEM** — What primary problem or combination of problems is the organization addressing?

76. **NEED_WHO_AFFECTED** — Who is most affected by the problem in the target service area?

77. **NEED_SCOPE** — How widespread or severe is the problem locally?

## Evidence

78. **NEED_EVIDENCE** — What current local, state, or national evidence demonstrates the need? Include source names and dates.

## Need

79. **NEED_CONSEQUENCES** — What happens to individuals, families, neighborhoods, employers, and public systems if the problem is not addressed?

80. **NEED_SERVICE_GAPS** — What specific gaps exist in current local services and why are existing resources insufficient?

## Evidence

81. **EVIDENCE_STATISTICS** — What verified statistics or research support the organization's theory of change?

82. **EVIDENCE_LOCAL_DATA** — What Pensacola/Escambia County data can be cited for homelessness, reentry, employment, housing, or related needs?

## Outcomes

83. **OUTCOMES_CURRENT** — What measurable outcomes has the organization already achieved?

84. **OUTCOMES_TARGETS** — What numeric 12-month targets will the organization commit to for housing, employment, retention, stability, and reentry?

85. **THEORY_OF_CHANGE** — State the theory of change linking activities to short-, intermediate-, and long-term outcomes.

## Evaluation

86. **EVALUATION_METHOD** — How will program success be measured, by whom, and how often?

87. **EVALUATION_DATA** — What participant, service, output, outcome, and follow-up data will be collected?

88. **EVALUATION_TOOLS** — What case-management, survey, database, spreadsheet, or other tools will store and analyze program data?

89. **EVALUATION_BASELINE** — What baseline measures will be collected at enrollment?

90. **EVALUATION_FOLLOWUP** — At what intervals will outcomes be measured after enrollment, placement, or exit?

## Success Stories

91. **EVIDENCE_SUCCESS_STORIES** — Describe approved participant success stories that may be used in proposals, with consent status.

92. **EVIDENCE_TESTIMONIALS** — What approved testimonials or firsthand evidence can be quoted or paraphrased?

## Partnerships

93. **PARTNERS_CURRENT** — Who are the organization's current partners and which relationships are documented?

94. **PARTNERS_ROLES** — What services, referrals, space, funding, jobs, training, healthcare, or other roles does each partner provide?

95. **PARTNERS_MOU** — Which partners have MOUs, letters of support, referral agreements, or other written commitments?

96. **PARTNERS_CORRECTIONS** — What corrections, jail, prison, probation, parole, or reentry-system partnerships exist or are being pursued?

97. **PARTNERS_HEALTH** — What medical, behavioral-health, substance-use, or recovery partnerships exist or are planned?

## Financial

98. **FIN_ANNUAL_BUDGET** — What is the organization's current annual operating budget?

99. **FIN_REVENUE** — What are the organization's current and projected revenue sources?

100. **FIN_EXPENSES** — What are the organization's major current and projected expense categories?

101. **FIN_CASH_ON_HAND** — How much unrestricted cash or operating reserve is currently available?

102. **FIN_OTHER_FUNDING** — What grants, donations, sponsorships, pledges, in-kind support, or other funding has been secured?

103. **FIN_GRANTS_RECEIVED** — List grants previously applied for, awarded, declined, or pending, including amount and funder.

104. **FIN_ACCOUNTING** — What accounting system, bookkeeping process, bank-account controls, and financial reporting practices are used?

105. **FIN_AUDIT** — Has the organization had an audit, review, compilation, or Form 990 filing? Provide the most recent status.

106. **FIN_MATCH** — What cash or in-kind match can the organization document for grants requiring cost share?

## Budget

107. **PROJECT_BUDGET_ASSUMPTIONS** — What unit costs and assumptions should GrantBot use when building project budgets?

108. **PROJECT_INDIRECT_RATE** — Does the organization have a negotiated indirect cost rate, elect the de minimis rate, or use another permitted method?

109. **PROJECT_PROCUREMENT** — What procurement, bidding, conflict, and vendor-selection procedures apply to grant-funded purchases?

## Implementation

110. **PROJECT_TIMELINE** — What is the implementation timeline for the next major program phase?

111. **PROJECT_MILESTONES** — What measurable milestones must be achieved during the grant period?

112. **PROJECT_RISKS** — What are the major implementation risks and mitigation strategies?

## Capacity

113. **ORG_ACCOMPLISHMENTS** — What are the organization's most important verified accomplishments to date?

114. **ORG_EXPERIENCE** — What direct experience does the organization and its leadership have addressing reentry, homelessness, housing, workforce, or related needs?

115. **ORG_CAPACITY** — What systems, people, property, partnerships, expertise, and controls demonstrate capacity to manage grant funds and deliver the proposed work?

116. **ORG_TECH_CAPACITY** — What computers, software, internet, case-management, security, and reporting systems are available?

## Sustainability

117. **SUSTAINABILITY** — How will programs continue after a grant period ends?

118. **SUSTAINABILITY_REVENUE** — What diversified future revenue sources can support ongoing operations?

119. **SUSTAINABILITY_EARNED_INCOME** — Will housing contributions, social enterprise, employer services, contracts, or other earned income support the model? Explain.

## Communications

120. **COMMUNICATIONS_CASE** — What concise case for support should be used with funders, donors, employers, churches, and community partners?

121. **COMMUNICATIONS_BRAND** — What approved organization name, logo, tagline, brand voice, and public claims may be used?
