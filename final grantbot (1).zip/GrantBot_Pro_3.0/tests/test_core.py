import os
import tempfile
import pytest
from grantbot.app import create_app
from grantbot.matcher import GrantMatcher
from grantbot.claim_checker import ClaimChecker
from grantbot.nofo import NOFOParser
from grantbot.budget import BudgetEngine

@pytest.fixture()
def app():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    app = create_app({"TESTING": True, "SQLALCHEMY_DATABASE_URI": f"sqlite:///{path}"})
    from grantbot.db import db
    with app.app_context():
        db.drop_all(); db.create_all()
    yield app
    os.unlink(path)

def test_status(app):
    response = app.test_client().get("/api/profile/status")
    assert response.status_code == 200
    assert response.json["total"] >= 100
    assert "required_completion_percent" in response.json

def test_seed_and_answer_round_trip(app):
    client = app.test_client()
    response = client.post("/api/profile/seed", json={})
    assert response.status_code == 200
    assert response.json["seeded"] > 0
    response = client.post("/api/profile/answer", json={"question_id":"ORG_MISSION","value":"We strengthen communities through housing and opportunity."})
    assert response.status_code == 200
    response = client.get("/api/profile")
    assert response.json["ORG_MISSION"]["answer"].startswith("We strengthen")

def test_unknown_question_rejected(app):
    r = app.test_client().post("/api/profile/answer", json={"question_id":"DOES_NOT_EXIST","value":"x"})
    assert r.status_code == 400

def test_requirement_analysis_employment(app):
    client = app.test_client(); client.post("/api/profile/seed", json={})
    r = client.post("/api/analyze/requirement", json={"prompt":"How will your program provide employment, job training, credentials and wages?"})
    assert r.status_code == 200
    assert r.json["category"] == "employment"
    assert "WORKFORCE_MODEL" in r.json["mapped_question_ids"]
    assert "WORKFORCE_WAGES" in r.json["mapped_question_ids"]

def test_writer_focus_and_missing_flags(app):
    client = app.test_client(); client.post("/api/profile/seed", json={})
    r = client.post("/api/draft", json={"prompt":"Describe employment and job training.", "word_limit":250})
    assert r.status_code == 200
    body = r.json
    assert "workforce" in body["narrative"].lower() or "employment" in body["narrative"].lower()
    assert "WORKFORCE_WAGES" in body["verification_needed"]
    assert body["safe_to_submit"] is False

def test_writer_can_become_submit_safe(app):
    client = app.test_client(); client.post("/api/profile/seed", json={})
    # Use a narrowly mapped prompt and fill all mapped questions reported by the engine.
    analysis = client.post("/api/analyze/requirement", json={"prompt":"What is your mission?"}).json
    for q in analysis["missing_question_ids"]:
        client.post("/api/profile/answer", json={"question_id":q,"value":f"Verified answer for {q}."})
    result = client.post("/api/draft", json={"prompt":"What is your mission?"}).json
    assert result["narrative"]
    assert result["claim_check"]["safe"] is True
    assert not result["verification_needed"]

def test_matcher_high_fit():
    opportunity = {"title":"Reentry Workforce and Supportive Housing Program", "description":"Job training, employment, transitional housing, case management for formerly incarcerated people", "status":"posted", "close_date":"12/31/2026", "applicant_types":[{"description":"Nonprofits having a 501(c)(3) status with the IRS"}], "agency":"Test Agency"}
    result = GrantMatcher().score(opportunity, {"ORG_501C3_STATUS":"Approved 501(c)(3)"})
    assert result["score"] >= 60
    assert result["priority"] in {"HIGH","MEDIUM"}

def test_matcher_hard_reject_academic():
    opportunity = {"title":"Postdoctoral Fellowship", "status":"posted", "applicant_types":[{"description":"Private institutions of higher education"}]}
    result = GrantMatcher().score(opportunity, {})
    assert result["priority"] == "REJECT"
    assert result["eligibility"]["hard_reject"] is True

def test_matcher_closed_rejected():
    result = GrantMatcher().score({"title":"Housing", "status":"closed"}, {})
    assert result["priority"] == "REJECT"

def test_claim_checker_numeric_invention():
    result = ClaimChecker().check("We will serve 500 people.", ["We currently serve 10 people."])
    assert result["safe"] is False
    assert result["unverified_numeric_claims"]

def test_claim_checker_authorized_number():
    result = ClaimChecker().check("We will serve 10 people.", ["We will serve 10 people."])
    assert result["safe"] is True

def test_nofo_parser_requirements():
    text = "Applicants must provide a project narrative. The narrative must not exceed 500 words. Applicants shall include a budget."
    result = NOFOParser().analyze(text)
    assert len(result["requirements"]) >= 2
    assert 500 in result["word_limits"]

def test_budget_reconcile():
    items = [{"category":"Personnel","description":"Coordinator","amount":40000},{"category":"Travel","description":"Local travel","amount":10000}]
    result = BudgetEngine().reconcile("The total request is $50,000.00.", items, requested_amount=50000)
    assert result["budget_total"] == 50000
    assert result["passed"] is True

def test_api_match(app):
    r = app.test_client().post("/api/grants/match", json={"title":"Homelessness supportive housing and workforce development", "status":"posted", "applicant_types":[{"description":"Nonprofits that do not have a 501(c)(3) status with the IRS"}]})
    assert r.status_code == 200
    assert "score" in r.json

def test_questions_endpoint(app):
    r = app.test_client().get("/api/profile/questions")
    assert r.status_code == 200
    assert len(r.json) >= 100
